const fs = require('fs');
const { d, styles, numbering, P, H1, H2, table, gap, run, headerFooter, INK, TEAL, GREY, STATUS } = require('./common');
const { Document, Paragraph, PageOrientation, BorderStyle } = d;
const W = 14838, cols = [800, 4200, 5600, 1500, 2738];
const head = ['Ref', 'Requirement (source)', 'DoctorNow position today', 'Status', 'Target / phase'];
const S = {
 A: ['A. Licensing and governance', [
  ['C-01', 'Platform assessed and approved by DHA before go-live (ST-14 cl. 7.6.2)', 'DHA application to be filed through the facility licensing section; this specification, the diagram dossier and this matrix support it.', 'Organisational', 'Before production'],
  ['C-02', 'Legal representation in Dubai with a commercial or trade licence (cl. 7.6.3)', 'DoctorNow to confirm and document its Dubai legal-representation arrangement.', 'Organisational', 'Before production'],
  ['C-03', 'Business Technical Director assigned (cl. 7.6.4)', 'To be named by DoctorNow.', 'Organisational', 'Before production'],
  ['C-04', 'Platform is a technology tool only: no clinical service, no recruiting of clinicians (cl. 7.8)', 'Clinical care is delivered by the facilities’ DHA-licensed doctors. Doctors are added by their facility’s admin; each hospital is approved by a DoctorNow Super Admin before activation.', 'Implemented', '—'],
  ['C-05', 'Technical support with escalation matrix and response/resolution times (cl. 7.6.5)', 'Support tickets and hospital-to-platform support chat exist. A documented escalation matrix with times is not yet defined.', 'Organisational', 'Before production'],
  ['C-06', 'Changes to core functions, data management or ownership reported to and approved by DHA; cooperation with DHA investigations and audits (cl. 7.7, 7.7.1)', 'Commitment by DoctorNow: no such change goes live without DHA approval. The audit trail (C-23) supports DHA audits.', 'Organisational', 'Ongoing'],
  ['C-07', 'Written agreement where more than one entity is involved (cl. 6.3)', 'Facility agreements covering platform use and data responsibilities to be signed per facility.', 'Organisational', 'Before pilot'],
  ['C-08', 'Quarterly KPI reporting to DHA (cl. 19.1)', 'Hospital Admin analytics and an export to help facilities prepare their access and quality KPIs are not yet available.', 'Planned', 'Before production'],
 ]],
 B: ['B. Hosting, residency and encryption', [
  ['C-09', 'Health data stored and processed in the UAE only (Federal Law 2/2019; ST-14 cl. 7.6.7, 8.2.5(d))', 'Production hosting is targeted at Microsoft Azure UAE North. Current environments are development/test and do not hold production patient data.', 'Planned', 'Before production'],
  ['C-10', 'Tier 3 data centre; DESC-certified UAE cloud provider (cl. 7.6.7 a, b)', 'Azure UAE North selected. Certification evidence to be provided at hosting sign-off.', 'Organisational', 'Before production'],
  ['C-11', 'ISO 27001 and HIPAA certification (cl. 7.6.7 c, d)', 'Hosting-provider certificates to be provided. DoctorNow’s own security-management certification route is to be decided.', 'Organisational', 'Before production'],
  ['C-12', 'Communication channels approved by TDRA (cl. 7.6.6)', 'Video is carried by Agora; DoctorNow issues tokens only. TDRA approval status of the channel is being confirmed.', 'Under assessment', 'Decision before production'],
  ['C-13', 'No transfer of health data outside the UAE except under Ministerial Decision 51/2021 (Law 2/2019)', 'External services (Agora, Firebase, Twilio, email provider, Stripe) are listed in the specification with their data and position. Clinical content is not sent to Stripe. Residency of the others is being assessed; UAE alternatives will be used where required.', 'Under assessment', 'Before production'],
  ['C-14', 'DHA-approved encryption for transmission and storage (cl. 6.5.2, 14.4.1)', 'Gateway applies security headers and HSTS; passwords are hashed; video media is encrypted by the provider. TLS termination at the Azure edge and encryption at rest with Key Vault keys are part of the Azure deployment.', 'Partial', 'Before production'],
 ]],
 C: ['C. Identity, access and consent', [
  ['C-15', 'Patient identified with at least three identifiers; identity verified before consultation (cl. 10.2.1, 14.1.2, 14.5.5)', 'Name, date of birth, Emirates ID and mobile number are held in the profile; the patient is authenticated by password and one-time code. Emirates ID format validation and a date-of-birth cross-check are not yet in place.', 'Partial', 'Emirates ID validation: before pilot'],
  ['C-16', 'User identification, authentication and access control (cl. 10.2.3, 5.5.5(o))', 'RS256 tokens (15 minutes), role checks for four roles, facility scoping for Hospital Admins, account lockout, session and token revocation, rate limiting. Second factor for Hospital Admin and Super Admin accounts is not yet in place.', 'Partial', 'Admin second factor: before pilot'],
  ['C-17', 'Documented informed consent, embedded in the workflow and kept in the record (cl. 10.1, 10.2.4–10.2.6)', 'Recording-consent request and acceptance are time-stamped on the consultation. A persisted telehealth and data-use consent before the first consultation is not yet built; the current privacy screen is not stored.', 'Partial', 'Before pilot'],
  ['C-18', 'Separate consent for audio recording, data storage and transfer (cl. 10.2.5)', 'Included in the consent work in C-17.', 'Planned', 'Before pilot'],
  ['C-19', 'Controls if video is recorded (cl. 9.7)', 'DoctorNow does not record audio or video. If recording is introduced, cl. 9.7 controls will be implemented first.', 'Implemented', '—'],
  ['C-20', 'Consultations offered in Arabic and English (cl. 14.1.6)', 'Doctors record the languages they consult in (including Arabic and English); Arabic voice search exists. The interface is in English; an Arabic interface is outside the current scope.', 'Partial', '—'],
 ]],
 D: ['D. Records and audit', [
  ['C-21', 'Complete encounter record: platform, licence numbers, consent, diagnosis, treatment, communications (cl. 11.6)', 'Doctor licence number, type and expiry; consultation notes, vitals, prescriptions, documents and chat are stored. Optional ICD-10 diagnosis selection and a consolidated consent confirmation are not yet in the record.', 'Partial', 'Before production'],
  ['C-22', 'Retention for at least 25 years; protection from unauthorised deletion or alteration (cl. 11.10, 8.2.5(a))', 'Hard-deletion paths for clinical records will be replaced by protected retention (no physical deletion; anonymisation where erasure is requested). The retention period will be configured as agreed with each facility and DHA; ST-14 cl. 11.10 specifies 25 years.', 'Planned', 'Before pilot'],
  ['C-23', 'Patient engagement documented for audit; consent auditable (cl. 9.9, 10.1.1)', 'Audit events record actor, role, action, target, facility, before/after values, IP and correlation ID, with sensitive fields redacted. Tamper-evident (write-once) storage and defined retention are not yet in place.', 'Partial', 'Before production'],
  ['C-24', 'Data available to DHA on request (cl. 8.2.7)', 'Super Admins can query audit and records through the platform. A structured export for DHA requests is not yet available.', 'Partial', 'Before production'],
 ]],
 E: ['E. Prescribing and clinical safety', [
  ['C-25', 'Teleprescribing only by a DHA-licensed physician in a licensed facility (cl. 17.12.1)', 'Prescriptions are issued by doctors onboarded with a recorded licence number and expiry. Automatic blocking when a licence has expired is not yet in place.', 'Partial', 'Before pilot'],
  ['C-26', 'No narcotic, controlled or semi-controlled medicines through telehealth (cl. 4.2.2, 17.12.7)', 'Medications carry a controlled flag; enforcement that blocks them is not yet in place.', 'Planned', 'Before pilot'],
  ['C-27', 'Prescribe from the MOHAP drug list; check contraindications (cl. 17.12.3, 17.12.6)', 'Medication catalogue exists; MOHAP drug-list alignment and interaction checks are not yet integrated.', 'Planned', 'Before production'],
  ['C-28', 'Sick leave through telehealth limited to 3 days per week (cl. 17.12.9)', 'Rule not enforced in the current release; inclusion in the prescribing workflow to be agreed.', 'Outside current scope', '—'],
  ['C-29', 'Emergencies excluded; emergency protocol and contact numbers (cl. 4.2.1, 12.4, 14.1.4)', 'Emergency notice in the patient app and the escalation protocol agreed with each facility are to be added.', 'Planned', 'Before pilot'],
 ]],
 F: ['F. Interoperability', [
  ['C-30', 'Facility health records integrate with NABIDH (cl. 7.9.1(e))', 'HL7 FHIR R4 read access (Patient, Encounter, Observation, Condition, MedicationRequest, Practitioner, patient summary) is built and connected to a Cerner sandbox. NABIDH integration and submission are carried out by each facility’s own EMR; DoctorNow-built NABIDH adapters are not part of the current release.', 'Organisational', 'Per facility'],
 ]],
 G: ['G. Billing and payments', [
  ['C-31', 'Billing, cancellation and refund policies defined and published (cl. 8.2.9, 8.4.1(j))', 'Refund API with reason categories exists. The default policy (full refund more than 24 h before, 50% between 6 and 24 h, none within 6 h or for a patient no-show, full refund if the doctor is unavailable; configurable per facility) will be applied automatically and published in the app.', 'Partial', 'Before pilot'],
  ['C-32', 'Facility is merchant of record; DoctorNow does not hold patient funds', 'Stripe Standard accounts and Direct Charges with no application fee, confirmed in writing by Stripe on 10 September 2026. Implementation and end-to-end testing are in progress.', 'Partial', 'Before pilot'],
  ['C-33', 'Eligibility verification and claims through eClaimLink (cl. 13.4, 13.6)', 'Insurance endpoints are simulated. Eligibility and claims stay with each facility’s own insurance and revenue-cycle systems; a Hospital Admin co-payment workflow is planned; live insurer or eClaimLink integration is outside the current release.', 'Organisational', 'Per facility'],
 ]],
 H: ['H. Privacy', [
  ['C-34', 'Privacy notice, data-subject rights, breach response (Law 2/2019; PDPL as applicable)', 'Not yet documented. To be prepared and confirmed with legal counsel.', 'Planned', 'Before pilot'],
 ]],
};
const counts = {}; Object.values(S).forEach(([, r]) => r.forEach(x => counts[x[3]] = (counts[x[3]] || 0) + 1));
const total = Object.values(counts).reduce((a, b) => a + b, 0);
const c = [];
c.push(new Paragraph({ children: [run('DoctrNow Healthcare LLC-FZ', { size: 22, bold: true, color: TEAL })], spacing: { after: 80 } }));
c.push(new Paragraph({ children: [run('DoctorNow Compliance Matrix', { size: 44, bold: true, color: INK })], spacing: { after: 80 } }));
c.push(new Paragraph({ children: [run('DN-COMP-MATRIX-2026 · Version 1.0 · 6 November 2026 · Companion to the Architecture Specification v1.1', { size: 20, color: GREY })], spacing: { after: 200 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: TEAL, space: 6 } } }));
c.push(P('This matrix lists each requirement that applies to the DoctorNow platform, what the product does today, and what is planned. Clause references are to the DHA Standards for Telehealth Services, DHA/HRS/HPSD/ST-14, Issue 4 (effective 26 November 2025), and to UAE Federal Law No. 2 of 2019. Status is assessed against the current codebase. Phases: **Before pilot** means before real patients use the service; **Before production** means before full go-live.'));
const order = ['Implemented', 'Partial', 'Planned', 'Under assessment', 'Organisational', 'Outside current scope'];
c.push(table([2120, 2120, 2120, 2120, 2120, 2120, 2118], [...order, 'Total'], [[...order.map(k => String(counts[k] || 0)), String(total)]], { size: 22 }));
c.push(gap());
Object.values(S).forEach(([title, rows]) => {
  c.push(H2(title));
  c.push(table(cols, head, rows, { statusCol: 3, size: 17 }));
  if (title[0] !== "H") c.push(gap());
});
c.push(P('Status terms: see Section 1.1 of the Architecture Specification. Under assessment and Organisational items depend on decisions or evidence outside the codebase and will be reported to DHA as they close. Outside current scope items will be scoped separately if a facility or DHA requires them.', { run: { italics: true, color: GREY, size: 16 } }));
const doc = new Document({
  creator: 'DoctrNow Healthcare LLC-FZ', title: 'DoctorNow Compliance Matrix v1.0', styles, numbering,
  sections: [{ properties: { page: { size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE }, margin: { top: 1100, bottom: 1000, left: 1000, right: 1000 } } }, ...headerFooter('DoctorNow Compliance Matrix · v1.0 · DN-COMP-MATRIX-2026', W), children: c }],
});
d.Packer.toBuffer(doc).then(b => { fs.writeFileSync('DoctorNow_Compliance_Matrix_v1.0.docx', b); console.log('matrix ok', JSON.stringify(counts)); });
