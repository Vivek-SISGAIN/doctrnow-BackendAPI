const fs = require('fs');
const { d, styles, numbering, P, H1, H2, B, table, gap, run, headerFooter, INK, TEAL, GREY } = require('./common');
const { Document, Packer, Paragraph, AlignmentType, PageBreak, BorderStyle } = d;
const W = 9638;
const c = [];

// ── Cover block
c.push(new Paragraph({ children: [run('DoctrNow Healthcare LLC-FZ', { size: 24, bold: true, color: TEAL })], spacing: { before: 1200, after: 200 } }));
c.push(new Paragraph({ style: 'Title', children: [run('DoctorNow')] }));
c.push(new Paragraph({ children: [run('Architecture Specification', { size: 40, bold: true, color: INK })], spacing: { after: 160 } }));
c.push(new Paragraph({ children: [run('Teleconsultation platform for DHA-licensed facilities — prepared for Dubai Health Authority IT review', { size: 24, color: GREY })], spacing: { after: 360 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: TEAL, space: 8 } } }));
c.push(table([2600, W - 2600], ['Item', 'Detail'], [
  ['Document reference', 'DN-ARCH-SPEC-2026'],
  ['Version / date', '1.1 — 6 November 2026'],
  ['Supersedes', 'Version 1.0 (DN-DHA-ARCH-2026-OFFICIAL, October 2026). Annex B lists what changed.'],
  ['Submitting entity', 'DoctrNow Healthcare LLC-FZ'],
  ['Companion documents', 'Architecture Diagram Dossier (DN-ARCH-DOSSIER-2026) · Compliance Matrix (DN-COMP-MATRIX-2026)'],
  ['Status', 'Issued for DHA IT review. Items not yet in the product are marked Planned, Under assessment, Organisational or Outside current scope.'],
]));
c.push(new Paragraph({ children: [new PageBreak()] }));

// ── 1 Introduction
c.push(H1('1. Introduction'));
c.push(P('DoctorNow is a web platform that lets patients book and attend teleconsultations with doctors of DHA-licensed hospitals and clinics. DoctorNow is a technology provider: clinical care is delivered by the facilities’ licensed doctors, and doctors are onboarded by their facility.'));
c.push(P('This specification explains how the platform is built, where data is held, how it is secured, how payments work and how it connects to hospital systems. It is written to be checked: every statement is marked with one of the status terms below, and the diagrams in the companion dossier use the same terms.'));
c.push(H2('1.1 Status terms'));
c.push(table([2200, W - 2200], ['Term', 'Meaning'], [
  ['Implemented', 'Present in the current DoctorNow codebase and demonstrable. (Shown as “Implemented” in the dossier legend.)'],
  ['Partial', 'Part of the requirement is in the codebase; the remainder is planned.'],
  ['Planned', 'Part of the current release plan but not yet built or deployed. Drawn with a dashed outline in the dossier.'],
  ['Under assessment', 'A decision or evidence is still being obtained (for example third-party data residency).'],
  ['Organisational', 'A licensing, contractual or process obligation of DoctorNow or the facility rather than a software feature.'],
  ['Outside current scope', 'Not part of the current release. It will be scoped separately if a facility or DHA requires it.'],
], { statusCol: 0 }));
c.push(gap());
c.push(H2('1.2 Regulatory basis'));
c.push(table([3300, W - 3300], ['Instrument', 'How DoctorNow relates to it'], [
  ['UAE Federal Law No. 2 of 2019 on the use of ICT in health fields', 'Health data is to be stored and processed inside the UAE, with cross-border transfer only under the exemptions in Ministerial Decision No. 51 of 2021. DoctorNow’s production hosting is targeted at Microsoft Azure UAE North (Section 3).'],
  ['DHA Standards for Telehealth Services, DHA/HRS/HPSD/ST-14, Issue 4 (effective 26 November 2025)', 'The main operational reference for platforms. The Compliance Matrix maps each applicable clause to a status.'],
  ['DHA / NABIDH policies', 'Integration of a facility’s health record with NABIDH is the facility’s obligation (ST-14 cl. 7.9.1(e)). DoctorNow provides HL7 FHIR R4 read access to facility systems (Section 7); DoctorNow-built NABIDH adapters are not part of the current release.'],
  ['UAE Federal Decree-Law No. 45 of 2021 (PDPL)', 'Applied as the baseline for personal data that is not governed by the health-sector law, subject to legal confirmation.'],
]));
c.push(P('This document does not claim certification or approval. DHA approval of the platform (ST-14 cl. 7.6.2) is a pending organisational step; this submission supports it.', { run: { italics: true, color: GREY } }));

// ── 2 Solution overview
c.push(H1('2. Solution overview'));
c.push(H2('2.1 Users and channels'));
c.push(P('Four roles use the platform: **Patient**, **Doctor**, **Hospital Admin** and **Super Admin** (DoctorNow platform staff). Each role has a web application, and Patients and Doctors also have mobile apps for iOS and Android (React Native), at the same stage of development as the web applications. All applications talk only to the API Gateway over HTTPS (dossier views SYS-01, MOD-00).'));
c.push(H2('2.2 Services'));
c.push(P('A single API Gateway fronts ten backend services. Each service owns its own database; services do not share tables (dossier SYS-08).'));
c.push(table([2500, W - 2500], ['Service', 'Responsibility'], [
  ['API Gateway', 'Sole entry point: token validation, role checks, rate limiting, routing, circuit breaker, video-token issuance, audit publishing.'],
  ['Identity', 'Registration, login, OTP second factor, sessions and token revocation, password reset, public signing keys (JWKS).'],
  ['Profile', 'Patients, doctors, administrators, insurance providers, family members, health profile.'],
  ['Appointment', 'Doctor availability, slot holds, appointment lifecycle, reminders.'],
  ['Consultation', 'Virtual lobby, recording-consent request, vitals, clinical notes, session closure.'],
  ['Video & Chat', 'Consultation chat and hospital-to-platform support chat (media itself is carried by the video provider).'],
  ['Medical Records', 'Prescriptions (PDF), medical documents, lab reports.'],
  ['Payment & Insurance', 'Stripe Connect integration, commission ledger and invoices, FHIR read access; insurance is simulated (Section 6.3).'],
  ['Notification', 'OTP, reminders, alerts, prescription email, in-app banners via email, SMS, push and sockets.'],
  ['Hospital Admin / Super Admin', 'Facility self-service (doctors, services, packages, finance views) and platform governance (hospital approval, commercial terms, support).'],
]));
c.push(gap());
c.push(H2('2.3 Technology'));
c.push(P('Node.js services (NestJS gateway and identity service), PostgreSQL per service accessed through Prisma, MongoDB for chat and the audit log, Redis for slot locks, rate limits and token revocation, BullMQ on Redis for appointment reminder jobs, RabbitMQ for the Notification service’s channel queues, Socket.io for real-time events, and React web applications. Kafka carries identity events in the Identity service; it is switched on by configuration and is on in the production profile.'));
c.push(H2('2.4 A typical consultation'));
c.push(P('A patient finds a doctor and holds a slot; pays on the facility’s Stripe Checkout; the appointment is confirmed and reminders are scheduled; at the time, patient and doctor enter the virtual lobby; the doctor requests recording consent; the consultation runs over the video provider with chat alongside; the doctor records notes and vitals and issues a prescription; the appointment is completed. Dossier view SYS-04 shows this as a sequence.'));

// ── 3 Hosting
c.push(H1('3. Hosting and data residency'));
c.push(P('**Position.** DoctorNow’s own services and databases in production will run entirely in **Microsoft Azure, UAE North (Dubai)**; third-party services are listed in Section 3.1. This is **Planned**. The current environments are development and test environments and are not used for patient data in production.'));
c.push(table([3000, W - 3000], ['Layer', 'Target (Azure UAE North)'], [
  ['Compute', 'Azure Kubernetes Service; container images in Azure Container Registry'],
  ['Relational data', 'Azure Database for PostgreSQL (one database per service)'],
  ['Chat and audit data', 'Azure Cosmos DB for MongoDB (or equivalent MongoDB service in the region)'],
  ['Cache and queues', 'Azure Cache for Redis; RabbitMQ within the cluster'],
  ['Documents', 'Azure Blob Storage with private endpoints (the code currently uses an S3-compatible client; the storage adapter will be changed)'],
  ['Edge and secrets', 'Front Door / Application Gateway with WAF and DDoS protection; Azure Key Vault; Azure Monitor'],
]));
c.push(gap());
c.push(P('Evidence of hosting-provider certification (DESC CSP Security Standard, Tier 3 data centre, ISO 27001) will be provided at hosting sign-off, as required by ST-14 cl. 7.6.7.'));
c.push(H2('3.1 Third-party services'));
c.push(P('DoctorNow uses the external services below. Each one is shown in dossier view SYS-06. Where residency is not yet established it is stated as such.'));
c.push(table([1700, 3000, W - 4700], ['Service', 'Data involved', 'Position'], [
  ['Stripe', 'Card payment processed on Stripe-hosted Checkout; amount, currency, a consultation-type label and DoctorNow reference IDs. No clinical notes or diagnoses are sent. Card data never reaches DoctorNow.', 'Payment data is handled by Stripe as the facility’s payment processor. Treated as non-clinical; legal confirmation of this treatment to be obtained.'],
  ['Agora (real-time video)', 'Audio and video media between patient and doctor. DoctorNow issues short-lived tokens and does not relay or record media.', '**Under assessment.** UAE residency of media routing and TDRA approval of the channel are being confirmed. No UAE-local relay is claimed.'],
  ['Firebase Cloud Messaging', 'Push notification text and device tokens.', 'Under assessment. Planned: notification text kept free of clinical detail.'],
  ['Twilio SMS', 'OTP codes and short alerts to mobile numbers.', 'Under assessment. SMS has a test (mock) mode that is used in development.'],
  ['SMTP email provider', 'Transactional email, including prescription delivery.', 'Under assessment. Planned: prescription delivery through a secure link or a UAE-based provider.'],
]));

// ── 4 Security
c.push(H1('4. Security and access control'));
c.push(H2('4.1 Authentication'));
c.push(B('**Tokens (Implemented).** Access tokens are RS256-signed JWTs valid for 15 minutes; the gateway verifies them against the Identity service’s public key endpoint (JWKS). Refresh tokens are stored hashed with a session record, and sessions can be revoked individually or all at once. Revoked tokens are blocked through a Redis list.'));
c.push(B('**Second factor (Partial).** Patients and doctors sign in with a password and a one-time code. Repeated failures lock the account. A second factor for Hospital Admin and Super Admin accounts is **Planned**.'));
c.push(B('**Passwords (Implemented).** Stored as salted hashes (argon2/bcrypt).'));
c.push(H2('4.2 Authorisation'));
c.push(P('Four roles (Patient, Doctor, Hospital Admin, Super Admin) are enforced at the gateway. Hospital Admins are scoped to their own facility by a tenant identifier carried in the verified token. The gateway forwards the verified user id, role and tenant to the services as request headers. Most calls between services also go through the gateway; a few internal endpoints are called directly and are protected by a shared secret header (Implemented). Services will be reachable only inside the private network of the Azure deployment (**Planned**, Section 3).'));
c.push(H2('4.3 Perimeter and transport'));
c.push(P('The gateway applies security headers, rate limiting and a circuit breaker (Implemented). TLS termination, WAF, DDoS protection and private subnets are part of the Azure deployment and are **Planned**. Encryption at rest will use the managed encryption of the Azure data services with keys in Azure Key Vault (**Planned**).'));
c.push(H2('4.4 Audit trail'));
c.push(P('The gateway records audit events in MongoDB: actor, role, action, target entity, facility, before and after values for data changes, IP address, user agent and a correlation ID, with passwords, tokens and card fields redacted. Super Admins can query all events and Hospital Admins their own facility’s (**Implemented**). Tamper-evident (write-once) storage, defined retention and compliance exports are **Planned**; the dedicated compliance service is a placeholder today.'));

// ── 5 Clinical
c.push(H1('5. Clinical workflow and records'));
c.push(B('**Facility and doctor onboarding (Implemented).** A Super Admin reviews and approves each hospital. The facility’s Hospital Admin adds doctors with licence number, licence type (DHA or HAAD) and licence expiry.'));
c.push(B('**Identity of the patient (Partial).** Name, date of birth, Emirates ID and mobile number are held in the patient profile. Format validation of the Emirates ID and a cross-check with the date of birth are **Planned**.'));
c.push(B('**Consent (Partial).** The doctor’s request for recording consent and the patient’s acceptance are time-stamped on the consultation. The platform does not record audio or video. A persisted, DHA-aligned telehealth and data-use consent captured before the first consultation is **Planned**; the current privacy screen in the patient app is not yet stored.'));
c.push(B('**Consultation record (Implemented).** Vitals, clinical notes and session history are stored per consultation. Optional ICD-10 code selection for the diagnosis is **Planned**.'));
c.push(B('**Prescriptions and documents (Implemented).** Doctors create, sign and send prescriptions as PDF; documents and lab reports are uploaded through short-lived signed links. Blocking of controlled and narcotic medicines (DHA teleprescribing rule) and the replacement of hard deletion of clinical records by protected retention are **Planned**. The DHA limit on sick leave issued through telehealth (3 days per week) is **outside the current scope**.'));
c.push(B('**Language (Partial).** Doctors record the languages they consult in (including Arabic and English); Arabic voice search exists. The interface is in English; an Arabic interface is outside the current scope.'));

// ── 6 Payments
c.push(H1('6. Payments — Stripe Connect Standard accounts with Direct Charges'));
c.push(P('**Status: target design, implementation in progress.** This section describes how payments will work in production; the Compliance Matrix and the dossier mark what is complete.'));
c.push(H2('6.1 Principles'));
c.push(B('Each hospital or clinic has its **own Stripe Standard account**, created through Stripe’s hosted onboarding. The facility completes identity, trade-licence and bank verification directly with Stripe.'));
c.push(B('Patients pay by card on **Stripe-hosted Checkout**. The charge is a **Direct Charge** created on the facility’s connected account, so the facility is the merchant of record and funds settle to the facility’s own balance and bank account. DoctorNow does not hold or pool patient funds.'));
c.push(B('DoctorNow takes **no fee at checkout** (application fee is zero). Its technology fee is recorded in an internal ledger and invoiced to the facility separately, as a business-to-business invoice.'));
c.push(B('Stripe confirmed in writing on 10 September 2026 that Standard connected accounts and Direct Charges are supported for UAE platforms and UAE facilities. The confirmation can be provided on request.'));
c.push(H2('6.2 Flow'));
c.push(table([500, 2300, W - 2800], ['#', 'Step', 'What happens'], [
  ['1', 'Facility onboarding', 'Hospital Admin starts onboarding; DoctorNow creates the Standard account and an onboarding link; the facility completes verification on Stripe; account status is synchronised by webhook and a 15-minute check. Patients can pay a facility only once its charges are enabled. (PAY-1)'],
  ['2', 'Checkout', 'Patient holds a slot and a pending appointment is created; DoctorNow creates a Checkout Session on the facility’s account; the patient pays on Stripe. (PAY-2)'],
  ['3', 'Confirmation', 'Confirmed three ways so no booking is lost: signed webhook, verification when the patient returns to the app, and a background check of payments still pending after 2 minutes. Webhook events are de-duplicated. Expired checkouts release the slot. (PAY-3)'],
  ['4', 'Refunds', 'Refunds are issued from the facility’s account by the facility or platform admin with a reason category; the matching share of commission is reversed. The refund policy to be applied is: full refund if cancelled more than 24 hours before the appointment, 50% between 6 and 24 hours, none within 6 hours or for a patient no-show, and a full refund if the doctor is unavailable. Applying this policy automatically, with per-facility configuration, is **Planned**. (PAY-4)'],
  ['5', 'Disputes', 'Card disputes are recorded for visibility; the facility responds in its own Stripe Dashboard. (PAY-4)'],
  ['6', 'Commission invoicing', 'Per billing period DoctorNow issues an invoice to each facility; the facility pays by bank transfer and submits the reference; DoctorNow acknowledges receipt. (PAY-5)'],
]));
c.push(gap());
c.push(H2('6.3 Insurance'));
c.push(P('Insurance coverage and claim endpoints are simulated in the current product. Eligibility checks and claims remain with each facility’s own insurance and revenue-cycle systems (ST-14 cl. 13.4, 13.6). A co-payment workflow, in which the Hospital Admin confirms eligibility and sets the co-payment that the patient then pays, is **Planned**. Live insurer or eClaimLink integration is outside the current release.'));

// ── 7 Interop
c.push(H1('7. Interoperability'));
c.push(P('DoctorNow exposes read access to Patient, Encounter, Observation, Condition, MedicationRequest and Practitioner resources, and a patient summary, through the gateway using HL7 FHIR R4. This is **Implemented** and is connected today to a Cerner FHIR R4 sandbox, which demonstrates the integration pattern (dossier SYS-03).'));
c.push(P('Under ST-14 cl. 7.9.1(e), each facility’s health record integrates with NABIDH. That integration, and the submission of clinical data to NABIDH, are carried out by the facility’s own EMR. DoctorNow-built NABIDH or EMR adapters are not part of the current release; if a facility or DHA requires one, it will be scoped separately.'));

// ── 8 Ops
c.push(H1('8. Operations and change control'));
c.push(P('The following are **Planned** and will be in place before production go-live: monitoring and alerting, backups and restore tests, a business-continuity and incident-response procedure, an emergency-escalation protocol agreed with each facility, and a support escalation matrix with response and resolution times (ST-14 cl. 7.6.5, 12.4). DoctorNow will report any change to core functions, data management or ownership to DHA and obtain DHA approval before it takes effect, and will cooperate with DHA investigations and audits (cl. 7.7, 7.7.1). Emergencies are outside the scope of telehealth (cl. 4.2.1); an emergency notice in the patient app is **Planned**.'));

// ── 9 Commitments
c.push(H1('9. Delivery commitments'));
c.push(P('The items below are the main gaps between the current product and the target described here. The full list, with ST-14 clause references, is in the Compliance Matrix.'));
c.push(table([500, 5300, W - 5800], ['#', 'Item', 'Planned phase'], [
  ['1', 'Complete the Stripe Standard / Direct Charge implementation and end-to-end testing', 'Before pilot'],
  ['2', 'Persisted telehealth and data-use consent', 'Before pilot'],
  ['3', 'Second factor for Hospital Admin and Super Admin accounts', 'Before pilot'],
  ['4', 'Teleprescribing rule: block controlled medicines; licence-expiry check at prescribing', 'Before pilot'],
  ['5', 'Protection of clinical records: no hard deletion; retention period configured as agreed with each facility and DHA (ST-14 cl. 11.10 specifies 25 years)', 'Before pilot'],
  ['6', 'Production hosting in Azure UAE North, encryption at rest, Key Vault, WAF', 'Before production'],
  ['7', 'Audit-log integrity protection, retention and compliance exports', 'Before production'],
  ['8', 'Decision and evidence on video, SMS, push and email provider residency', 'Before production'],
  ['9', 'Emirates ID format validation; optional ICD-10 diagnosis selection', 'Before pilot'],
  ['10', 'DHA platform approval, Dubai legal representative, Business Technical Director, support escalation matrix', 'Organisational'],
]));
c.push(gap());
c.push(H2('9.1 Outside the current scope'));
c.push(P('The following are not part of the current release. Each will be scoped separately if a facility or DHA requires it: DoctorNow-built NABIDH and EMR adapters; live insurer or eClaimLink integration; an Arabic user interface; enforcement of the DHA sick-leave limit (3 days per week) in the prescribing workflow.'));

// ── Annex A
c.push(H1('Annex A. Diagram dossier index'));
c.push(table([1300, W - 1300], ['View', 'Title'], [
  ['SYS-01 to SYS-08', 'Platform Context · Runtime & Hosting Topology · Healthcare Interoperability Boundary · Teleconsultation Session Flow · Payment Architecture — Direct Charges · Data Classification & Residency · Security Controls · Service Dependency Map'],
  ['MOD-00 to MOD-12', 'Client Applications · API Gateway · Identity & Access · Profile & Registry · Appointment & Scheduling · Consultation · Video & Chat · Medical Records & e-Prescription · Payment & Insurance components · Notification · Hospital Admin · Super Admin · Audit & Compliance'],
  ['PAY-1 to PAY-5', 'Facility Stripe Onboarding · Checkout & Payment Confirmation · Webhook Processing & Reconciliation · Refunds & Disputes · Commission Invoicing'],
]));

// ── Annex B
c.push(H1('Annex B. Changes from version 1.0'));
c.push(P('Version 1.1 aligns the text with the current codebase and distinguishes implemented features from planned ones.'));
c.push(table([3100, W - 3100], ['Topic', 'Change'], [
  ['Status wording', 'The single “fully compliant” label is replaced by Implemented, Partial, Planned, Under assessment, Organisational and Outside current scope, with a separate Compliance Matrix.'],
  ['Hosting and residency', 'Production hosting in Azure UAE North is stated as the target; third-party services are listed individually with their residency position.'],
  ['Video', 'The reference to UAE-local media relays is removed; the video provider is described as under assessment.'],
  ['Audit', '“Write-once, tamper-evident” storage is described as planned; what is implemented today is stated.'],
  ['Sign-in', 'The statement on HttpOnly refresh cookies is removed; the OTP second factor scope (patients and doctors) is stated; Emirates ID is described as captured, with format validation planned.'],
  ['Interoperability', 'Per-record NABIDH synchronisation attributes are removed; FHIR R4 access and the Cerner sandbox connection are described as built, and NABIDH submission and EMR adapters as the facility’s responsibility, outside the current release.'],
  ['Mobile apps', 'The Patient and Doctor mobile apps are described as available, at the same stage as the web applications, instead of planned.'],
  ['Payments', 'Described as the target Standard / Direct Charge design, with the default refund policy, refund automation planned, and insurance noted as simulated with a co-payment workflow planned.'],
  ['References', 'DHA Telehealth Regulations is replaced by ST-14 Issue 4; “NABDH” is corrected to NABIDH.'],
]));

const doc = new Document({
  creator: 'DoctrNow Healthcare LLC-FZ', title: 'DoctorNow Architecture Specification v1.1', styles, numbering,
  sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1300, bottom: 1200, left: 1134, right: 1134 } } }, ...headerFooter('DoctorNow Architecture Specification · v1.1 · DN-ARCH-SPEC-2026'), children: c }],
});
d.Packer.toBuffer(doc).then(b => { fs.writeFileSync('DoctorNow_Architecture_Specification_v1.1.docx', b); console.log('spec ok'); });
