const d = require('docx');
const { Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle, AlignmentType, HeadingLevel, LevelFormat, Header, Footer, PageNumber, TabStopType } = d;
const INK = '12394F', TEAL = '0F766E', GREY = '5B6770', LINE = 'C9D3D9';
const FONT = 'Arial';
const STATUS = {
  'Implemented': { fill: 'E3F3E6', color: '1E6B2E' },
  'Partial': { fill: 'FFF3D6', color: '8A5A00' },
  'Planned': { fill: 'FDE9D9', color: '9A3F00' },
  'Organisational': { fill: 'E6ECF7', color: '1D3F7A' },
  'Under assessment': { fill: 'F3E5F5', color: '5B2A86' },
  'Outside current scope': { fill: 'ECEFF1', color: '3F4A54' },
};
const styles = {
  default: { document: { run: { font: FONT, size: 21 } } },
  paragraphStyles: [
    { id: 'Title', name: 'Title', basedOn: 'Normal', run: { font: FONT, size: 52, bold: true, color: INK }, paragraph: { spacing: { before: 0, after: 120 } } },
    { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 30, bold: true, color: INK }, paragraph: { spacing: { before: 360, after: 120 }, keepNext: true, outlineLevel: 0 } },
    { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 24, bold: true, color: TEAL }, paragraph: { spacing: { before: 240, after: 80 }, keepNext: true, outlineLevel: 1 } },
  ],
};
const numbering = { config: [{ reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] };
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, ...o });
// inline **bold** support
function runs(text, o = {}) {
  return String(text).split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(s => s.startsWith('**') ? run(s.slice(2, -2), { bold: true, ...o }) : run(s, o));
}
const P = (t, o = {}) => new Paragraph({ children: runs(t, o.run || {}), spacing: { before: 0, after: 120, line: 288 }, alignment: o.align, keepNext: o.keepNext });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [run(t)] });
const B = t => new Paragraph({ numbering: { reference: 'bul', level: 0 }, children: runs(t), spacing: { before: 0, after: 60, line: 276 } });
const border = { style: BorderStyle.SINGLE, size: 4, color: LINE };
const borders = { top: border, bottom: border, left: border, right: border };
function cell(t, w, o = {}) {
  const paras = (Array.isArray(t) ? t : [t]).map(x => new Paragraph({ children: runs(x, { size: o.size || 18, bold: o.bold, color: o.color }), spacing: { before: 0, after: 40, line: 252 } }));
  return new TableCell({ children: paras, width: { size: w, type: WidthType.DXA }, borders, shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined, margins: { top: 60, bottom: 60, left: 90, right: 90 } });
}
function table(widths, head, rows, o = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const hr = new TableRow({ tableHeader: true, cantSplit: true, children: head.map((h, i) => cell(h, widths[i], { bold: true, fill: INK, color: 'FFFFFF', size: o.size || 18 })) });
  const rs = rows.map(r => new TableRow({ cantSplit: true, children: r.map((c, i) => {
    if (o.statusCol === i && STATUS[c]) return cell(c, widths[i], { bold: true, fill: STATUS[c].fill, color: STATUS[c].color, size: o.size || 18 });
    return cell(c, widths[i], { size: o.size || 18, fill: o.zebra && rows.indexOf(r) % 2 ? 'F6F8F9' : undefined });
  }) }));
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, rows: [hr, ...rs] });
}
const gap = () => new Paragraph({ children: [], spacing: { before: 0, after: 120 } });
function headerFooter(title, pos = 9638) {
  return {
    headers: { default: new Header({ children: [new Paragraph({ children: [run(title, { size: 16, color: GREY })], border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: LINE, space: 4 } } })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ tabStops: [{ type: TabStopType.RIGHT, position: pos }], children: [run('DoctrNow Healthcare LLC-FZ · Confidential', { size: 16, color: GREY }), run('\tPage ', { size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY }), run(' of ', { size: 16, color: GREY }), new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 16, color: GREY })] })] }) },
  };
}
module.exports = { d, styles, numbering, P, H1, H2, B, table, gap, run, runs, headerFooter, INK, TEAL, GREY, STATUS, cell };
