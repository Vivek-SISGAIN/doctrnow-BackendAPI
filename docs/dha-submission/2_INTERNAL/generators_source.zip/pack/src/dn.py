"""DoctrNow diagram toolkit: one spec -> SVG + PNG + draw.io (graph + sequence)."""
import html, json, os, subprocess, re
from xml.sax.saxutils import escape as xesc

FONT = "Inter"
KINDS = {
    "built":    dict(fill="#E7F0FA", line="#1D4E89", dash=False, label="Implemented — DoctorNow service / component"),
    "data":     dict(fill="#EAF6E7", line="#3F7D20", dash=False, label="Data store"),
    "external": dict(fill="#EEEAF8", line="#4C3D91", dash=False, label="External provider"),
    "hospital": dict(fill="#E0F4F2", line="#0F766E", dash=False, label="Hospital / regulator system"),
    "user":     dict(fill="#FFF1E0", line="#B45309", dash=False, label="User / client channel"),
    "security": dict(fill="#FDEBEB", line="#B3261E", dash=False, label="Security / edge control"),
    "neutral":  dict(fill="#EEF0F3", line="#475569", dash=False, label="Platform / operations"),
    "planned":  dict(fill="#FFF9DB", line="#C28A00", dash=True,  label="Planned (not yet in code)"),
}
CL = {  # cluster background / border / title colour
    "built":    ("#F3F8FD", "#1D4E89"), "data": ("#F5FAF3", "#3F7D20"),
    "external": ("#F8F6FD", "#4C3D91"), "hospital": ("#F2FAF9", "#0F766E"),
    "user":     ("#FFF9F2", "#B45309"), "security": ("#FFF4F4", "#B3261E"),
    "neutral":  ("#F7F8FA", "#475569"), "planned": ("#FFFDF0", "#9A6B00"),
    "cloud":    ("#F2F7FB", "#1D4E89"),
}
EDGE = {  # style, colour
    "sync":  ("solid", "#475569"), "async": ("dashed", "#475569"),
    "ref":   ("dotted", "#78909C"), "money": ("solid", "#3F7D20"),
    "plan":  ("dashed", "#9A6B00"), "hid": ("invis", "#FFFFFF"), "sec": ("solid", "#B3261E"),
}

def _lbl(label, sub=None, planned=False, size=13):
    s = f'<B>{html.escape(label)}</B>'
    if sub:
        for ln in sub.split("\n"):
            s += f'<BR/><FONT POINT-SIZE="{size-3}" COLOR="#37474F">{html.escape(ln)}</FONT>'
    if planned:
        s += f'<BR/><FONT POINT-SIZE="{size-4}" COLOR="#9A6B00"><B>PLANNED</B></FONT>'
    return f'<{s}>'

class Graph:
    def __init__(self, gid, title, rankdir="LR", nodesep=0.45, ranksep=0.9, size=13, splines="true"):
        self.gid, self.title, self.rankdir = gid, title, rankdir
        self.nodesep, self.ranksep, self.size, self.splines = nodesep, ranksep, size, splines
        self.nodes, self.clusters, self.edges = {}, {}, []
        self.kinds_used = set(); self.samerank = []

    def cluster(self, cid, label, kind="neutral", parent=None):
        self.clusters[cid] = dict(label=label, kind=kind, parent=parent); return cid

    def node(self, nid, label, sub=None, kind="built", cluster=None, planned=False, w=None):
        if planned: kind = "planned"
        self.nodes[nid] = dict(label=label, sub=sub, kind=kind, cluster=cluster, planned=planned or kind == "planned", w=w)
        self.kinds_used.add(kind); return nid

    def same(self, *ids): self.samerank.append(ids)

    def edge(self, a, b, label=None, kind="sync", num=None, both=False, constraint=True, weight=None):
        if num: label = f"{num}  {label}" if label else str(num)
        self.edges.append(dict(a=a, b=b, label=label, kind=kind, both=both, constraint=constraint, weight=weight))

    # ---------- DOT ----------
    def dot(self):
        S = self.size
        o = [f'digraph "{self.gid}" {{',
             f'  graph [rankdir={self.rankdir}, nodesep={self.nodesep}, ranksep={self.ranksep}, fontname="{FONT}", '
             f'splines={self.splines}, compound=true, newrank=true, pad=0.35, bgcolor="white", '
             f'labelloc=t, labeljust=l, fontsize={S+5}, label=<<B>{html.escape(self.title)}</B>>];',
             f'  node [shape=box, style="rounded,filled", fontname="{FONT}", fontsize={S}, penwidth=1.7, margin="0.18,0.10"];',
             f'  edge [fontname="{FONT}", fontsize={S-2}, color="#475569", arrowsize=0.8, penwidth=1.3];']
        def emit_cluster(cid, ind):
            c = self.clusters[cid]; bg, fg = CL[c["kind"]]
            o.append(f'{ind}subgraph "cluster_{cid}" {{')
            o.append(f'{ind}  label=<<B>{html.escape(c["label"])}</B>>; labeljust=l; fontcolor="{fg}"; color="{fg}"; pencolor="{fg}"; '
                     f'fillcolor="{bg}"; style="rounded,filled"; penwidth=1.8; fontsize={S}; margin=16;')
            for nid, n in self.nodes.items():
                if n["cluster"] == cid: o.append(f'{ind}  {self._n(nid, n)}')
            for k, cc in self.clusters.items():
                if cc["parent"] == cid: emit_cluster(k, ind + "  ")
            o.append(f'{ind}}}')
        for cid, c in self.clusters.items():
            if c["parent"] is None: emit_cluster(cid, "  ")
        for nid, n in self.nodes.items():
            if n["cluster"] is None: o.append(f'  {self._n(nid, n)}')
        for ids in self.samerank: o.append('  {rank=same; ' + '; '.join(f'"{i}"' for i in ids) + ';}')
        for e in self.edges:
            sty, col = EDGE[e["kind"]]
            a = [f'style={sty}', f'color="{col}"', f'fontcolor="#263238"']
            if e["label"]: a.append(f'label=<{html.escape(e["label"])}>')
            if e["both"]: a.append('dir=both')
            if not e["constraint"]: a.append('constraint=false')
            if e["weight"]: a.append(f'weight={e["weight"]}')
            o.append(f'  "{e["a"]}" -> "{e["b"]}" [{", ".join(a)}];')
        o.append('}'); return "\n".join(o)

    def _n(self, nid, n):
        k = KINDS[n["kind"]]
        st = "rounded,filled,dashed" if k["dash"] else "rounded,filled"
        w = f', width={n["w"]}' if n["w"] else ""
        return (f'"{nid}" [label={_lbl(n["label"], n["sub"], n["planned"], self.size)}, fillcolor="{k["fill"]}", '
                f'color="{k["line"]}", style="{st}"{w}];')

    # ---------- render ----------
    def render(self, outdir):
        base = os.path.join(outdir, self.gid)
        dot = self.dot(); open(base + ".dot", "w").write(dot)
        subprocess.run(["dot", "-Tsvg", base + ".dot", "-o", base + ".svg"], check=True)
        js = subprocess.run(["dot", "-Tjson", base + ".dot"], check=True, capture_output=True, text=True).stdout
        png(base + ".svg", base + ".png", self.kinds_used)
        return base, json.loads(js)

    def drawio_cells(self, js):
        H = float(js["bb"].split(",")[3])
        cells, byname = [], {}
        nid = [1]
        def new(): nid[0] += 1; return f"{self.gid}-{nid[0]}"
        # clusters first (z-order); parents before children
        objs = js.get("objects", [])
        def depth(name):
            cid = name.replace("cluster_", "", 1); d = 0
            while self.clusters.get(cid, {}).get("parent"): cid = self.clusters[cid]["parent"]; d += 1
            return d
        cl = [x for x in objs if x["name"].startswith("cluster_")]
        for x in sorted(cl, key=lambda x: depth(x["name"])):
            cid = x["name"].replace("cluster_", "", 1); c = self.clusters[cid]
            llx, lly, urx, ury = [float(v) for v in x["bb"].split(",")]
            bg, fg = CL[c["kind"]]; i = new(); byname[x["name"]] = i
            st = (f"rounded=1;arcSize=3;html=1;whiteSpace=wrap;fillColor={bg};strokeColor={fg};strokeWidth=2;"
                  f"verticalAlign=top;align=left;spacingLeft=12;spacingTop=4;fontStyle=1;fontColor={fg};fontSize=13;")
            cells.append(dict(id=i, v=1, value=xesc(c["label"]), style=st, x=llx, y=H - ury, w=urx - llx, h=ury - lly))
        for x in objs:
            if x["name"].startswith("cluster_") or x["name"] not in self.nodes: continue
            n = self.nodes[x["name"]]; k = KINDS[n["kind"]]
            cx, cy = [float(v) for v in x["pos"].split(",")]
            w, h = float(x["width"]) * 72, float(x["height"]) * 72; i = new(); byname[x["name"]] = i
            val = f"<b>{xesc(n['label'])}</b>"
            if n["sub"]: val += "".join(f"<br><font style='font-size:10px'>{xesc(s)}</font>" for s in n["sub"].split("\n"))
            if n["planned"]: val += "<br><font style='font-size:9px' color='#9A6B00'><b>PLANNED</b></font>"
            st = (f"rounded=1;arcSize=14;html=1;whiteSpace=wrap;fillColor={k['fill']};strokeColor={k['line']};"
                  f"strokeWidth=2;fontSize=12;fontColor=#000000;" + ("dashed=1;" if k["dash"] else ""))
            cells.append(dict(id=i, v=1, value=val.replace("<", "&lt;").replace(">", "&gt;"), style=st,
                              x=cx - w / 2, y=H - cy - h / 2, w=w, h=h, rawhtml=True))
        for e in [x for x in self.edges if x["kind"] != "hid"]:
            sty, col = EDGE[e["kind"]]; i = new()
            st = (f"edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;strokeColor={col};strokeWidth=1.6;endArrow=block;"
                  f"fontSize=10;labelBackgroundColor=#FFFFFF;" + ("dashed=1;" if sty == "dashed" else "dashed=1;dashPattern=1 3;" if sty == "dotted" else "")
                  + ("startArrow=block;" if e["both"] else ""))
            cells.append(dict(id=i, e=1, value=xesc(e["label"] or ""), style=st, src=byname.get(e["a"]), dst=byname.get(e["b"])))
        return cells, js["bb"].split(",")


def png(svg, out, kinds_used, scale=2.2, legend=True):
    subprocess.run(["rsvg-convert", "-z", str(scale), "-b", "white", svg, "-o", out], check=True)
    if not legend: return
    from PIL import Image, ImageDraw, ImageFont
    im = Image.open(out).convert("RGB"); W = im.width
    f = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Regular.otf", int(11 * scale))
    items = [KINDS[k] for k in ["user", "built", "data", "external", "hospital", "security", "neutral", "planned"] if k in kinds_used]
    pad, sw = int(14 * scale), int(14 * scale)
    # lay out legend in rows that fit width
    rows, row, x = [], [], pad
    for it in items:
        tw = int(f.getlength(it["label"])) + sw + int(26 * scale)
        if x + tw > W - pad and row: rows.append(row); row, x = [], pad
        row.append((it, x)); x += tw
    rows.append(row)
    rh = int(24 * scale); H = len(rows) * rh + pad
    out_im = Image.new("RGB", (W, im.height + H), "white"); out_im.paste(im, (0, 0))
    d = ImageDraw.Draw(out_im); y0 = im.height + int(4 * scale)
    d.line([(pad, y0 - 2), (W - pad, y0 - 2)], fill="#CFD8DC", width=2)
    for r, row in enumerate(rows):
        for it, x in row:
            y = y0 + r * rh + int(4 * scale)
            d.rounded_rectangle([x, y, x + sw, y + sw], radius=4, fill=it["fill"], outline=it["line"], width=3)
            d.text((x + sw + int(8 * scale), y - int(1 * scale)), it["label"], fill="#37474F", font=f)
    out_im.save(out)


# ====================== sequence diagrams ======================
class Seq:
    COLW, ROWH, TOP, LEFT = 210, 52, 96, 40
    def __init__(self, gid, title):
        self.gid, self.title = gid, title; self.parts, self.steps = [], []; self.kinds_used = set()
    def part(self, pid, label, sub=None, kind="built"):
        if kind == "planned": pass
        self.parts.append(dict(id=pid, label=label, sub=sub, kind=kind)); self.kinds_used.add(kind)
    def msg(self, a, b, text, kind="sync", num=None): self.steps.append(dict(t="msg", a=a, b=b, text=text, kind=kind, num=num))
    def note(self, a, text, b=None): self.steps.append(dict(t="note", a=a, b=b or a, text=text))
    def sec(self, text): self.steps.append(dict(t="sec", text=text))

    def _x(self, pid):
        i = [p["id"] for p in self.parts].index(pid); return self.LEFT + i * self.COLW + self.COLW // 2

    def layout(self):
        y = self.TOP + 64; items = []
        for s in self.steps:
            if s["t"] == "sec": y += 14; items.append((s, y, 34)); y += 40
            elif s["t"] == "note":
                lines = self._wrap(s["text"], 30 if s["a"] == s["b"] else 60); h = 18 * len(lines) + 12
                items.append((s, y, h)); y += h + 14
            else:
                lines = self._wrap(s["text"], max(28, int(abs(self._x(s["b"]) - self._x(s["a"])) / 7) if s["a"] != s["b"] else 24))
                h = 16 * len(lines) + 20; items.append((s, y, h)); y += h + 8
        return items, y + 30

    @staticmethod
    def _wrap(t, n):
        out, cur = [], ""
        for w in t.split():
            if len(cur) + len(w) + 1 > n and cur: out.append(cur); cur = w
            else: cur = (cur + " " + w).strip()
        if cur: out.append(cur)
        return out or [""]

    def svg(self):
        items, H = self.layout(); W = self.LEFT * 2 + self.COLW * len(self.parts)
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="{FONT}">',
             '<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#37474F"/></marker>'
             '<marker id="g" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#3F7D20"/></marker></defs>',
             f'<rect width="{W}" height="{H}" fill="white"/>',
             f'<text x="{self.LEFT}" y="34" font-size="19" font-weight="700" fill="#000">{xesc(self.title)}</text>']
        for p in self.parts:
            k = KINDS[p["kind"]]; x = self._x(p["id"]); bw = self.COLW - 28
            o.append(f'<line x1="{x}" y1="{self.TOP + 52}" x2="{x}" y2="{H - 14}" stroke="#90A4AE" stroke-width="1.4" stroke-dasharray="5 5"/>')
            o.append(f'<rect x="{x - bw // 2}" y="{self.TOP - 8}" width="{bw}" height="60" rx="10" fill="{k["fill"]}" stroke="{k["line"]}" stroke-width="2"'
                     + (' stroke-dasharray="6 4"' if k["dash"] else '') + '/>')
            o.append(f'<text x="{x}" y="{self.TOP + 18}" text-anchor="middle" font-size="12.5" font-weight="700">{xesc(p["label"])}</text>')
            if p["sub"]: o.append(f'<text x="{x}" y="{self.TOP + 36}" text-anchor="middle" font-size="10" fill="#37474F">{xesc(p["sub"])}</text>')
        for s, y, h in items:
            if s["t"] == "sec":
                o.append(f'<rect x="{self.LEFT}" y="{y}" width="{W - 2 * self.LEFT}" height="{h - 6}" rx="6" fill="#EEF0F3"/>')
                o.append(f'<text x="{self.LEFT + 12}" y="{y + 20}" font-size="12.5" font-weight="700" fill="#37474F">{xesc(s["text"])}</text>')
            elif s["t"] == "note":
                xa, xb = sorted([self._x(s["a"]), self._x(s["b"])]); wdt = max(xb - xa + 150, 170); x0 = (xa + xb) / 2 - wdt / 2
                o.append(f'<rect x="{x0}" y="{y}" width="{wdt}" height="{h}" rx="6" fill="#FFF9DB" stroke="#C28A00" stroke-dasharray="4 3"/>')
                for i, ln in enumerate(self._wrap(s["text"], 30 if s["a"] == s["b"] else 60)):
                    o.append(f'<text x="{x0 + wdt / 2}" y="{y + 17 + 16 * i}" text-anchor="middle" font-size="10.5" fill="#5D4037">{xesc(ln)}</text>')
            else:
                xa, xb = self._x(s["a"]), self._x(s["b"]); sty, col = EDGE[s["kind"]]
                dash = ' stroke-dasharray="6 4"' if sty == "dashed" else ' stroke-dasharray="2 4"' if sty == "dotted" else ""
                mk = "g" if s["kind"] == "money" else "a"
                lines = self._wrap(s["text"], max(28, int(abs(xb - xa) / 7) if xa != xb else 24))
                ly = y + 14 * 1; ay = y + h - 10
                txt = (f'{s["num"]}  ' if s["num"] else "")
                if xa == xb:
                    o.append(f'<path d="M{xa},{y + 6} h46 v{h - 16} h-46" fill="none" stroke="{col}" stroke-width="1.6"{dash} marker-end="url(#{mk})"/>')
                    for i, ln in enumerate(lines): o.append(f'<text x="{xa + 54}" y="{y + 16 + 15 * i}" font-size="11" fill="#263238">{xesc((txt if i == 0 else "") + ln)}</text>')
                else:
                    o.append(f'<line x1="{xa}" y1="{ay}" x2="{xb}" y2="{ay}" stroke="{col}" stroke-width="1.7"{dash} marker-end="url(#{mk})"/>')
                    mx = (xa + xb) / 2
                    for i, ln in enumerate(lines): o.append(f'<text x="{mx}" y="{y + 12 + 15 * i}" text-anchor="middle" font-size="11" fill="#263238">{xesc((txt if i == 0 else "") + ln)}</text>')
        o.append('</svg>'); return "\n".join(o), W, H, items

    def render(self, outdir):
        base = os.path.join(outdir, self.gid); svg, W, H, items = self.svg()
        open(base + ".svg", "w").write(svg); png(base + ".svg", base + ".png", self.kinds_used, scale=1.8)
        self._items, self._W, self._H = items, W, H
        return base, None

    def drawio_cells(self, js=None):
        cells, n = [], [1]
        def new(): n[0] += 1; return f"{self.gid}-{n[0]}"
        H = self._H; ids = {}
        for p in self.parts:
            k = KINDS[p["kind"]]; x = self._x(p["id"]); bw = self.COLW - 28; i = new(); ids[p["id"]] = i
            val = f"<b>{xesc(p['label'])}</b>" + (f"<br><font style='font-size:10px'>{xesc(p['sub'])}</font>" if p["sub"] else "")
            cells.append(dict(id=i, v=1, value=val.replace("<", "&lt;").replace(">", "&gt;"), rawhtml=True,
                              style=f"rounded=1;html=1;whiteSpace=wrap;fillColor={k['fill']};strokeColor={k['line']};strokeWidth=2;fontSize=12;" + ("dashed=1;" if k["dash"] else ""),
                              x=x - bw // 2, y=self.TOP - 8, w=bw, h=60))
            cells.append(dict(id=new(), e=1, value="", style="endArrow=none;dashed=1;strokeColor=#90A4AE;html=1;",
                              pts=((x, self.TOP + 52), (x, H - 14))))
        for s, y, h in self._items:
            if s["t"] == "sec":
                cells.append(dict(id=new(), v=1, value=xesc(s["text"]), style="rounded=1;html=1;fillColor=#EEF0F3;strokeColor=none;fontStyle=1;align=left;spacingLeft=10;fontSize=12;fontColor=#37474F;",
                                  x=self.LEFT, y=y, w=self._W - 2 * self.LEFT, h=h - 6))
            elif s["t"] == "note":
                xa, xb = sorted([self._x(s["a"]), self._x(s["b"])]); wdt = max(xb - xa + 150, 170)
                cells.append(dict(id=new(), v=1, value=xesc(s["text"]), style="rounded=1;html=1;whiteSpace=wrap;fillColor=#FFF9DB;strokeColor=#C28A00;dashed=1;fontSize=10;fontColor=#5D4037;",
                                  x=(xa + xb) / 2 - wdt / 2, y=y, w=wdt, h=h))
            else:
                xa, xb = self._x(s["a"]), self._x(s["b"]); sty, col = EDGE[s["kind"]]; ay = y + h - 10
                st = (f"html=1;strokeColor={col};strokeWidth=1.7;endArrow=block;fontSize=10;labelBackgroundColor=#FFFFFF;verticalAlign=bottom;"
                      + ("dashed=1;" if sty == "dashed" else "dashed=1;dashPattern=1 3;" if sty == "dotted" else ""))
                lab = ((s["num"] + "  ") if s["num"] else "") + s["text"]
                if xa == xb: cells.append(dict(id=new(), e=1, value=xesc(lab), style=st, pts=((xa, y + 8), (xa + 1, y + h - 8))))
                else: cells.append(dict(id=new(), e=1, value=xesc(lab), style=st, pts=((xa, ay), (xb, ay))))
        return cells, (0, 0, self._W, self._H)


# ====================== draw.io writer ======================
HOWTO = 'How to read these diagrams. Solid boxes are implemented in the current DoctorNow codebase. Dashed yellow boxes marked "Planned" are part of the current release plan but not yet built or deployed. Payment views (SYS-05, MOD-08, PAY-1 to PAY-5) show the target design; implementation is in progress. Status terms match the Architecture Specification (Section 1.1) and the Compliance Matrix.'
def drawio_page(name, cells, bb):
    W, H = (float(bb[2]), float(bb[3])) if len(bb) == 4 else (1600, 1000)
    o = [f'<diagram name="{xesc(name)}" id="{xesc(name)}"><mxGraphModel dx="{int(W)}" dy="{int(H)}" grid="0" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" pageScale="1" pageWidth="{int(W) + 80}" pageHeight="{int(H) + 80}" math="0" shadow="0"><root><mxCell id="0"/><mxCell id="1" parent="0"/>']
    for c in cells:
        if c.get("v"):
            val = c["value"]
            o.append(f'<mxCell id="{c["id"]}" value="{val if c.get("rawhtml") else val}" style="{c["style"]}" vertex="1" parent="1"><mxGeometry x="{c["x"]:.1f}" y="{c["y"]:.1f}" width="{c["w"]:.1f}" height="{c["h"]:.1f}" as="geometry"/></mxCell>')
        else:
            if "pts" in c:
                (x1, y1), (x2, y2) = c["pts"]
                o.append(f'<mxCell id="{c["id"]}" value="{c["value"]}" style="{c["style"]}" edge="1" parent="1"><mxGeometry relative="1" as="geometry"><mxPoint x="{x1}" y="{y1}" as="sourcePoint"/><mxPoint x="{x2}" y="{y2}" as="targetPoint"/></mxGeometry></mxCell>')
            else:
                s = f' source="{c["src"]}"' if c.get("src") else ""; t = f' target="{c["dst"]}"' if c.get("dst") else ""
                o.append(f'<mxCell id="{c["id"]}" value="{c["value"]}" style="{c["style"]}" edge="1" parent="1"{s}{t}><mxGeometry relative="1" as="geometry"/></mxCell>')
    o.append('</root></mxGraphModel></diagram>'); return "".join(o)


class Pack:
    """Collects diagrams; renders everything; writes drawio."""
    def __init__(self, outdir): self.outdir, self.items = outdir, []; os.makedirs(outdir, exist_ok=True)
    def add(self, ref, group, title, purpose, notes, diagram):
        self.items.append(dict(ref=ref, group=group, title=title, purpose=purpose, notes=notes, d=diagram))
    def build(self):
        pages = [drawio_page('How to read these diagrams', [dict(id='how-1', v=1, value=xesc(HOWTO).replace('"', '&quot;'), style='rounded=1;arcSize=4;html=1;whiteSpace=wrap;fillColor=#F4F8FB;strokeColor=#1D4E89;strokeWidth=2;align=left;verticalAlign=middle;spacing=16;fontSize=15;', x=40, y=40, w=900, h=170)], (0, 0, 1000, 260))]
        for it in self.items:
            d = it["d"]; base, js = d.render(self.outdir); it["base"] = base
            cells, bb = d.drawio_cells(js) if isinstance(d, Graph) else d.drawio_cells()
            pages.append(drawio_page(f'{it["ref"]} {it["title"]}', cells, bb))
        open(os.path.join(self.outdir, "DoctorNow_Architecture_Dossier.drawio"), "w").write(
            '<?xml version="1.0" encoding="UTF-8"?><mxfile host="app.diagrams.net">' + "".join(pages) + '</mxfile>')
