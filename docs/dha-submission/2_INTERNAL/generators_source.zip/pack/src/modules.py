from dn import Graph, Seq

def mod(pack, ref, title, purpose, notes, g):
    pack.add(ref, "Payment flows" if ref.startswith("PAY") else "Modules", title, purpose, notes, g)

def build(pack):
    # ───────── MOD-00 Client applications ─────────
    g = Graph("MOD00_Client_Applications", "MOD-00 · Client Applications", "LR", ranksep=1.0)
    g.cluster("spa", "Client applications (web: React / Vite · mobile: React Native)", "user")
    g.node("pa", "Patient app", "search · book · pay · consult · records", "user", "spa")
    g.node("da", "Doctor portal", "queue · consult · notes · e-Rx", "user", "spa")
    g.node("ha", "Hospital admin portal", "doctors · services · revenue & invoices", "user", "spa")
    g.node("sa", "Super admin console", "hospital approvals · finance · support", "user", "spa")
    g.node("ma", "Patient & Doctor mobile apps", "iOS / Android (React Native)", "user", "spa")
    g.node("gw", "API Gateway", "single HTTPS entry point", "security")
    g.node("agsdk", "Agora RTC SDK", "patient & doctor media", "external")
    g.node("fb", "Firebase SDK", "push token registration", "external")
    g.node("st", "Stripe-hosted Checkout", "redirect for card payment", "external")
    g.node("ws", "Socket.io realtime", "chat · lobby · notifications", "built")
    for a in ["pa", "da", "ha", "sa", "ma"]: g.edge(a, "gw", "REST / JSON (JWT)")
    g.edge("pa", "agsdk", "audio / video", "async"); g.edge("da", "agsdk", "audio / video", "async"); g.edge("ma", "agsdk", "audio / video", "async")
    g.edge("pa", "st", "redirect to pay", "money")
    for a in ["pa", "da", "ha", "ma"]: g.edge(a, "fb", "device token", "async")
    for a in ["pa", "da", "ha", "sa", "ma"]: g.edge(a, "ws", None, "async")
    mod(pack, "MOD-00", "Client Applications", "The role-specific web applications, the mobile apps for patients and doctors, and the third-party SDKs they use directly.",
        ["All business calls go through the API Gateway with a JWT; clients never call internal services.",
         "Media streams connect straight from the browser or mobile app to Agora using a short-lived token issued by DoctorNow.",
         "Card details are entered only on Stripe-hosted Checkout; the patient apps never handle card numbers.",
         "The Patient and Doctor mobile apps (iOS and Android, React Native) use the same gateway and APIs as the web applications."], g)

    # ───────── MOD-01 API Gateway ─────────
    g = Graph("MOD01_API_Gateway", "MOD-01 · API Gateway", "TB", ranksep=0.9, nodesep=0.5)
    g.node("cl", "Clients", "web applications", "user")
    g.cluster("gwc", "API Gateway (NestJS)", "security")
    g.node("gd", "Security pipeline", "helmet · rate limiting\nJWT guard (RS256 via JWKS) · role check", "security", "gwc")
    g.node("rv", "Token revocation", "blacklist lookup (Redis)", "security", "gwc")
    g.node("px", "Routing / proxy", "per-domain controllers\nrequest context: user id · role · tenant", "built", "gwc")
    g.node("cb", "Circuit breaker", "protects downstream services", "built", "gwc")
    g.node("ag", "Agora token endpoint", "short-lived RTC tokens", "built", "gwc")
    g.node("au", "Audit publisher", "business + request audit events\nredacts passwords · tokens · card fields", "built", "gwc")
    g.node("rd", "Redis", "revocation · rate limit", "data")
    g.node("mg", "MongoDB audit log", "append-only audit events", "data")
    g.node("svc", "Domain services", "identity · profile · appointment · consultation\nrecords · payment · notification · admin", "built")
    g.node("jw", "Identity service", "JWKS public keys", "built")
    g.edge("cl", "gd", "HTTPS"); g.edge("gd", "rv"); g.edge("rv", "rd", None, "ref"); g.edge("gd", "jw", "fetch JWKS", "ref")
    g.edge("rv", "px"); g.edge("px", "cb"); g.edge("cb", "svc", "REST"); g.edge("px", "ag", None, "ref"); g.edge("px", "au", None, "async"); g.edge("au", "mg", None, "async")
    mod(pack, "MOD-01", "API Gateway", "The single secured entry point: authentication, authorisation, throttling, routing, token issuance for video and the audit trail.",
        ["Every request is validated (signature, expiry, revocation) before it is routed; downstream services receive the verified user id, role and tenant as request headers.",
         "A circuit breaker isolates failing services so one outage does not cascade.",
         "Business and request audit events are stored in MongoDB with sensitive fields redacted and are queryable by authorised admins.",
         "Services publish business audit events to the gateway. Most calls between services also go through it; a few internal endpoints are called directly and are protected by a shared secret header."], g)

    # ───────── MOD-02 Identity ─────────
    g = Graph("MOD02_Identity_Access", "MOD-02 · Identity & Access Service", "LR", ranksep=1.0)
    g.node("gw", "API Gateway", None, "security")
    g.cluster("ids", "Identity service (auth-service)", "built")
    g.node("reg", "Registration & login", "register · login · login/otp · me\naccount lockout · doctor status check", "built", "ids")
    g.node("otp", "OTP service", "send · verify · expiry · retries", "built", "ids")
    g.node("pw", "Password reset", "request · confirm (single-use token)", "built", "ids")
    g.node("tok", "Token service", "RS256 access (15 min) · refresh · logout\nlogout-all · session revocation", "built", "ids")
    g.node("jk", "JWKS endpoint", "publishes public signing keys", "built", "ids")
    g.cluster("st", "Identity data", "data")
    g.node("pg", "PostgreSQL", "User · Session · OtpRequest\nPasswordResetToken · JwtKey", "data", "st")
    g.node("kf", "Kafka (event bus)", "session and OTP events\nswitched on by configuration", "data")
    g.node("nt", "Notification service", "queues the OTP in RabbitMQ\nsends SMS / email", "built")
    g.node("mfa", "Second factor for admin roles", "hospital admin · super admin", "planned")
    g.edge("gw", "reg"); g.edge("reg", "otp"); g.edge("reg", "tok"); g.edge("pw", "otp", None, "ref"); g.edge("tok", "jk", None, "ref")
    g.edge("reg", "pg"); g.edge("tok", "pg"); g.edge("otp", "pg"); g.edge("otp", "nt", "dispatch OTP (HTTP)", "sync"); g.edge("tok", "kf", "session events", "async"); g.edge("reg", "mfa", None, "plan")
    mod(pack, "MOD-02", "Identity & Access", "Authentication, session and token management for all four roles.",
        ["Patients and doctors sign in with a password plus an OTP second factor; repeated failures trigger account lockout. Access tokens are RS256-signed and short-lived (15 minutes); sessions can be revoked individually or all at once.",
         "Public keys are published through a JWKS endpoint so the gateway can verify tokens without sharing secrets.",
         "OTP delivery is requested from the Notification service, which queues it for asynchronous delivery.",
         "Planned: a second factor for hospital admin and super admin accounts."], g)

    # ───────── MOD-03 Profile ─────────
    g = Graph("MOD03_Profile_Registry", "MOD-03 · Profile & Registry Service", "LR", ranksep=1.0)
    g.node("gw", "API Gateway", None, "security")
    g.cluster("ps", "Profile service", "built")
    g.node("pt", "Patients & health profile", "demographics · Emirates ID\nhealth profile · family members", "built", "ps")
    g.node("dr", "Doctors & specialties", "licence · specialty · hospital link", "built", "ps")
    g.node("ad", "Admin profiles", "hospital admin · super admin", "built", "ps")
    g.node("in", "Insurance providers", "provider catalogue", "built", "ps")
    g.node("sr", "Internal search", "hospital / doctor lookup\nfor other services", "built", "ps")
    g.node("pg", "PostgreSQL", "Patient · PatientHealthProfile · FamilyMember\nSpecialty · Doctor · HospitalAdmin · SuperAdmin\nInsuranceProvider", "data")
    g.node("s3", "Object storage", "profile images · documents", "data")
    g.node("pay", "Payment · Hospital Admin · Notification", "patient, doctor and hospital lookups", "built")
    g.node("oth", "Appointment · Consultation · Super Admin", "read-only lookups made by Profile", "built")
    g.node("fac", "Hospital EHR master patient index", "Emirates ID cross-check", "planned")
    g.edge("gw", "pt"); g.edge("gw", "dr"); g.edge("gw", "ad"); g.edge("gw", "in")
    for a in ["pt", "dr", "ad", "in"]: g.edge(a, "pg", None)
    g.edge("pt", "s3", "uploads", "async"); g.edge("pay", "sr", "internal API", "ref"); g.edge("pt", "oth", None, "ref"); g.edge("pt", "fac", None, "plan")
    mod(pack, "MOD-03", "Profile & Registry", "System of record for patients, doctors, administrators and insurance providers.",
        ["Holds PII (name, Emirates ID, contact) in PostgreSQL; files are stored in object storage using short-lived signed uploads.",
         "Other services read doctor and hospital data through internal lookup endpoints rather than sharing the database.",
         "Planned: Emirates ID cross-check against hospital master patient indices."], g)

    # ───────── MOD-04 Appointment ─────────
    g = Graph("MOD04_Appointment_Scheduling", "MOD-04 · Appointment & Scheduling Service", "TB", ranksep=1.0, nodesep=0.5)
    g.node("gw", "API Gateway", None, "security")
    g.cluster("as", "Appointment service", "built")
    g.node("sl", "Slot management", "single · bulk · availability\nnext-available search", "built", "as")
    g.node("lk", "Slot locking", "temporary hold during checkout\nprevents double booking", "built", "as")
    g.node("ap", "Appointment lifecycle", "create → confirm → extend\ncomplete · no-show", "built", "as")
    g.node("jb", "Scheduled jobs", "slot maintenance · no-show checks\nreminder jobs 15 / 3 / 1 min before (BullMQ)", "built", "as")
    g.node("pg", "PostgreSQL", "Slot · Appointment · SlotLock", "data")
    g.node("rd", "Redis", "slot locks · BullMQ reminder queue", "data")
    g.node("pay", "Payment service", "payment-outcome: PAID / FAILED", "built")
    g.node("nt", "Notification service", None, "built")
    g.node("co", "Consultation service", "reads / completes appointment", "built")
    g.edge("gw", "sl"); g.edge("gw", "ap"); g.edge("ap", "lk"); g.edge("sl", "pg"); g.edge("ap", "pg"); g.edge("lk", "rd")
    g.edge("jb", "rd", "reminder jobs", "ref"); g.edge("jb", "nt", "deliver reminders", "async")
    g.edge("pay", "ap", "internal callback", "sync"); g.edge("co", "ap", "state updates", "sync")
    mod(pack, "MOD-04", "Appointment & Scheduling", "Doctor availability, slot holds and the appointment lifecycle.",
        ["A slot is locked while the patient pays; the Payment service confirms or releases it through an internal callback.",
         "Background jobs handle slot maintenance, no-show checks and reminder scheduling; reminders are BullMQ jobs on Redis that re-check the appointment status before they are delivered.",
         "Slots are managed in DoctorNow by each facility's Hospital Admin and doctors."], g)

    # ───────── MOD-05 Consultation ─────────
    g = Graph("MOD05_Consultation", "MOD-05 · Consultation Service", "TB", ranksep=1.0, nodesep=0.5)
    g.node("pd", "Patient / Doctor apps", None, "user")
    g.node("gw", "API Gateway", None, "security")
    g.cluster("cs", "Consultation service", "built")
    g.node("lb", "Virtual lobby", "join-lobby · presence\nSocket.io (Redis adapter)", "built", "cs")
    g.node("cn", "Consent", "request / accept recording consent", "built", "cs")
    g.node("hd", "Health details & vitals", "pre-consult details · vitals", "built", "cs")
    g.node("nt", "Clinical notes", "create · save · update", "built", "cs")
    g.node("en", "Session end & history", "end · extension · history · metrics", "built", "cs")
    g.node("pg", "PostgreSQL", "Consultation · ConsultationNote\nConsultationVitals", "data")
    g.node("rd", "Redis", "socket scale-out", "data")
    g.node("ap", "Appointment service", None, "built")
    g.node("ag", "Agora channel (name only)", "tokens issued by gateway", "external")
    g.edge("pd", "gw"); g.edge("gw", "lb"); g.edge("lb", "cn"); g.edge("cn", "hd"); g.edge("hd", "nt"); g.edge("nt", "en")
    for a in ["hd", "nt", "en"]: g.edge(a, "pg")
    g.edge("lb", "rd", None, "ref"); g.edge("en", "ap", "complete appointment"); g.edge("lb", "ag", "channel", "ref")
    mod(pack, "MOD-05", "Consultation", "Orchestrates a consultation session: lobby, consent, vitals, clinical notes and closure.",
        ["The lobby links the appointment to an Agora channel and records when recording consent was requested and accepted. DoctorNow does not record audio or video.",
         "Notes and vitals are stored in the service's own PostgreSQL database and are accessible only to the treating doctor and the patient."], g)

    # ───────── MOD-06 Video & Chat ─────────
    g = Graph("MOD06_Video_Chat", "MOD-06 · Video & Chat Service", "TB", ranksep=1.0, nodesep=0.5)
    g.node("pd", "Patient / Doctor / Admin apps", None, "user")
    g.node("gw", "API Gateway", None, "security")
    g.cluster("vs", "Video & Chat service", "built")
    g.node("ch", "Consultation chat", "messages · attachments · read state\nmute · pin · archive · search", "built", "vs")
    g.node("ss", "Chat sessions", "create · start · end · participants", "built", "vs")
    g.node("sp", "Support chat", "hospital/admin ↔ platform support\nrequests · accept · resolve", "built", "vs")
    g.node("rt", "Realtime layer", "Socket.io + Redis adapter", "built", "vs")
    g.node("mg", "MongoDB", "messages · conversations · sessions", "data")
    g.node("s3", "Object storage", "chat attachments", "data")
    g.node("rd", "Redis", "socket scale-out", "data")
    g.edge("pd", "gw"); g.edge("gw", "ch"); g.edge("gw", "sp"); g.edge("ch", "ss"); g.edge("ch", "rt", None, "async"); g.edge("sp", "rt", None, "async")
    g.edge("ch", "mg"); g.edge("sp", "mg"); g.edge("ch", "s3", "attachments", "async"); g.edge("rt", "rd", None, "ref")
    mod(pack, "MOD-06", "Video & Chat", "Real-time chat during consultations and support conversations between hospitals and the platform.",
        ["Chat content is stored in MongoDB; attachments go to object storage through short-lived signed access.",
         "Audio and video are carried directly by Agora; this service manages chat sessions and participant state only."], g)

    # ───────── MOD-07 Medical Records ─────────
    g = Graph("MOD07_Medical_Records_eRx", "MOD-07 · Medical Records & e-Prescription Service", "LR", ranksep=1.0)
    g.node("dp", "Doctor portal / Patient app", None, "user")
    g.node("gw", "API Gateway", None, "security")
    g.cluster("ms", "Medical records service", "built")
    g.node("rx", "e-Prescription", "create · sign · send · view · PDF\nmedications · precautions · diet", "built", "ms")
    g.node("dc", "Medical documents", "upload via short-lived signed URL\nconfirm · list · download", "built", "ms")
    g.node("lr", "Lab reports", "create · view by patient / doctor", "built", "ms")
    g.node("pg", "PostgreSQL", "Prescription · PrescriptionMedication\nMedicalDocument · LabReport", "data")
    g.node("s3", "Object storage", "documents · Rx PDFs · reports\nshort-lived signed URLs · server-side encryption", "data")
    g.node("nt", "Notification service", "prescription email / alert", "built")
    g.edge("dp", "gw"); g.edge("gw", "rx"); g.edge("gw", "dc"); g.edge("gw", "lr")
    g.edge("rx", "pg"); g.edge("dc", "pg"); g.edge("lr", "pg"); g.edge("dc", "s3", "short-lived signed", "async"); g.edge("rx", "s3", "PDF", "async")
    g.edge("rx", "nt", "prescription available", "async")
    mod(pack, "MOD-07", "Medical Records & e-Prescription", "Prescriptions, medical documents and lab reports.",
        ["Prescriptions support sign, send and view actions performed by the doctor and patient, with PDF generation.",
         "Files are uploaded straight to object storage with short-lived signed URLs, then confirmed to the service."], g)

    # ───────── MOD-08 Payment & Insurance (component) ─────────
    g = Graph("MOD08_Payment_Service", "MOD-08 · Payment & Insurance Service — components", "TB", ranksep=0.8, nodesep=0.4)
    g.node("gw", "API Gateway", None, "security")
    g.cluster("ps", "Payment service (Stripe Connect Standard · Direct Charges)", "built")
    g.node("on", "Facility onboarding", "Standard account · onboarding link\nstatus sync", "built", "ps")
    g.node("ck", "Checkout", "Checkout Session on hospital account\napplication fee = 0", "built", "ps")
    g.node("wh", "Webhook handlers", "signature check · idempotent\nplatform + Connect endpoints", "built", "ps")
    g.node("rc", "Reconciliation", "verify-on-return · 2-min stuck scan\n15-min account status poll", "built", "ps")
    g.node("rf", "Refunds & disputes", "refunds on hospital account\ndispute records", "built", "ps")
    g.node("lg", "Commission ledger & invoices", "per-transaction commission\nperiodic B2B invoice lifecycle", "built", "ps")
    g.node("ap", "Reporting APIs", "patient · hospital · admin views", "built", "ps")
    g.node("pg", "PostgreSQL", "Transaction · Refund · Dispute\nCommissionInvoice · Payout\nPatientPaymentProfile · ProcessedWebhookEvent", "data")
    g.node("st", "Stripe (UAE)", None, "external")
    g.node("sa", "Super Admin service", "commission terms · Stripe status", "built")
    g.node("apt", "Appointment service", "payment-outcome", "built")
    g.node("ins", "Insurance claims integration", "coverage check · claim submission", "planned")
    for a in ["on", "ck", "ap"]: g.edge("gw", a, None)
    g.edge("st", "wh", "signed events", "async"); g.edge("wh", "rc", None, "ref"); g.edge("ck", "rf", None, "ref"); g.edge("rf", "lg", None, "ref")
    for a in ["ck", "wh", "rf", "lg"]: g.edge(a, "pg", None)
    g.edge("on", "st", "Accounts API", "money"); g.edge("ck", "st", "Checkout Sessions", "money"); g.edge("rf", "st", "Refunds", "money")
    g.edge("ck", "sa", "commission rate · account id", "ref"); g.edge("on", "sa", "status", "ref"); g.edge("rc", "apt", "PAID / FAILED", "sync"); g.edge("ap", "ins", None, "plan")
    mod(pack, "MOD-08", "Payment & Insurance — components", "Internal structure of the Payment service.",
        ["Every Stripe call that moves patient money is made on behalf of the hospital's connected account; DoctorNow holds no patient funds.",
         "Webhook events are de-duplicated with a processed-event table so Stripe retries are safe.",
         "The commission ledger only records amounts owed; collection happens through a separate invoice, not through Stripe.",
         "Insurance coverage and claim endpoints exist as a simulated service only; insurance eligibility is checked by the facility in its own insurance system, and live insurer or eClaimLink integration is outside the current release."], g)

    # ───────── PAY-1 Facility onboarding (sequence) ─────────
    s = Seq("PAY1_Facility_Stripe_Onboarding", "PAY-1 · Facility Onboarding — Stripe Standard connected account")
    s.part("ha", "Hospital admin", "portal", "user"); s.part("gw", "API Gateway", "JWT · tenant", "security")
    s.part("pay", "Payment service", "Connect"); s.part("sa", "Super Admin svc", "hospital record")
    s.part("st", "Stripe (UAE)", "Accounts · onboarding", "external")
    s.sec("1 · Create the account and onboarding link")
    s.msg("ha", "gw", "Start Stripe onboarding", num="①"); s.msg("gw", "pay", "request onboarding link (hospital from tenant)", num="②")
    s.msg("pay", "sa", "read hospital & stored Stripe account id", num="③")
    s.msg("pay", "st", "no account yet → create Standard account (full dashboard)", "money", "④")
    s.msg("pay", "sa", "store stripeAccountId, status = PENDING", num="⑤")
    s.msg("pay", "st", "create account link (return / refresh URLs)", "money", "⑥")
    s.msg("pay", "ha", "onboarding URL", "sync", "⑦")
    s.sec("2 · Hospital completes verification on Stripe")
    s.msg("ha", "st", "business details · licence · signatory ID · IBAN (Stripe-hosted)", "async", "⑧")
    s.msg("st", "pay", "account.updated (Connect webhook)", "async", "⑨")
    s.msg("pay", "sa", "update status: charges / payouts enabled → COMPLETE", num="⑩")
    s.sec("3 · Return and safety nets")
    s.msg("ha", "pay", "returns to portal → sync status on demand", num="⑪"); s.msg("pay", "st", "retrieve account state", "sync", "⑫")
    s.note("pay", "A background job re-checks PENDING / RESTRICTED facilities every 15 minutes. Checkout is refused until the hospital has an account with charges enabled.", "st")
    mod(pack, "PAY-1", "Facility Stripe Onboarding", "How a hospital connects its own Stripe Standard account to DoctorNow.",
        ["The hospital owns the Stripe account and completes identity, trade-licence and bank verification directly with Stripe.",
         "DoctorNow stores only the account id and status flags; it never sees bank or identity documents.",
         "Patients can pay for a hospital's consultations only after the hospital's charges are enabled."], s)

    # ───────── PAY-2 Checkout & payment confirmation ─────────
    s = Seq("PAY2_Checkout_Payment_Confirmation", "PAY-2 · Checkout and Payment Confirmation — Direct Charge")
    s.part("pat", "Patient app", "", "user"); s.part("gw", "API Gateway", "JWT", "security"); s.part("pay", "Payment service", "")
    s.part("sa", "Super Admin svc", "commission terms"); s.part("st", "Stripe (UAE)", "hospital's account", "external")
    s.part("ap", "Appointment svc", "slot hold")
    s.sec("1 · Create the checkout on the hospital's account")
    s.msg("pat", "gw", "book slot (slot locked temporarily)", num="①"); s.msg("gw", "pay", "create checkout session", num="②")
    s.msg("pay", "sa", "get hospital Stripe account & commission rate", num="③")
    s.msg("pay", "pay", "save Transaction = PENDING with commission owed", "sync", "④")
    s.msg("pay", "st", "create Checkout Session on hospital account · no application fee", "money", "⑤")
    s.msg("pay", "pat", "checkout URL (expiring)", "sync", "⑥")
    s.sec("2 · Patient pays on Stripe")
    s.msg("pat", "st", "card / wallet details + 3-D Secure (Stripe-hosted)", "money", "⑦")
    s.msg("st", "pay", "checkout.session.completed (webhook)", "async", "⑧")
    s.msg("pay", "st", "retrieve session, payment & fee details", "sync", "⑨")
    s.msg("pay", "pay", "Transaction = SUCCESS · store fee, net, card brand/last4, receipt", "sync", "⑩")
    s.msg("pay", "ap", "payment-outcome PAID → appointment CONFIRMED", "sync", "⑪")
    s.sec("3 · Return path (no waiting for the webhook)")
    s.msg("pat", "pay", "returns to app → verify session", "sync", "⑫")
    s.msg("pay", "pat", "PAID / PENDING / FAILED", "sync", "⑬")
    s.note("pay", "Expired or abandoned checkouts mark the Transaction FAILED and release the slot.", "ap")
    mod(pack, "PAY-2", "Checkout & Payment Confirmation", "Direct Charge sequence from slot selection to a confirmed appointment.",
        ["The Checkout Session is created on the hospital's connected account, so funds settle to the hospital and the hospital is the Merchant of Record.",
         "The patient's return and the Stripe webhook both confirm the payment; whichever arrives first wins and the other is a safe no-op.",
         "Only the commission owed is recorded; no amount is transferred to or retained by DoctorNow."], s)

    # ───────── PAY-3 Webhook & reconciliation ─────────
    g = Graph("PAY3_Webhook_Reconciliation", "PAY-3 · Webhook Processing and Three-Tier Reconciliation", "TB", ranksep=1.0, nodesep=0.5)
    g.cluster("t1", "Tier 1 — signed webhooks", "built")
    g.node("st", "Stripe (UAE)", "platform + Connect webhooks", "external")
    g.node("v", "Signature verification", "raw body · webhook secret", "built", "t1")
    g.node("id", "Idempotency check", "ProcessedWebhookEvent (event id)", "data", "t1")
    g.node("h", "Event handlers", "account.updated · checkout.session.completed/expired\ncharge.refunded · charge.dispute.created/closed", "built", "t1")
    g.cluster("t2", "Tier 2 — return verification", "built")
    g.node("ret", "Patient returns to app", "verify by session / appointment id", "user", "t2")
    g.cluster("t3", "Tier 3 — background reconciliation", "built")
    g.node("cr", "Stuck-payment scan (every 2 min)", "PENDING older than 2 min, up to 48 h", "built", "t3")
    g.node("sp", "Account status poll (every 15 min)", "PENDING / RESTRICTED facilities", "built", "t3")
    g.node("rfs", "Stuck-refund scan (hourly)", "re-checks refunds not yet confirmed", "built", "t3")
    g.node("rc", "Reconciliation service", "retrieve session on hospital account\nset SUCCESS / FAILED / PENDING", "built")
    g.node("db", "PostgreSQL", "Transaction · Refund · Dispute", "data")
    g.node("ap", "Appointment service", "payment-outcome", "built")
    g.node("sa", "Super Admin service", "facility status", "built")
    g.edge("st", "v", "event", "async"); g.edge("v", "id"); g.edge("id", "h", "new event only"); g.edge("h", "rc", "checkout events")
    g.edge("ret", "rc"); g.edge("cr", "rc"); g.edge("rfs", "rc", None, "ref"); g.edge("rc", "st", "retrieve (stripeAccount)", "ref")
    g.edge("rc", "db"); g.edge("rc", "ap", "PAID / FAILED"); g.edge("h", "db", "refund · dispute updates"); g.edge("sp", "sa", "status update"); g.edge("h", "sa", "account.updated")
    mod(pack, "PAY-3", "Webhook Processing & Reconciliation", "How payment state stays correct when webhooks are delayed, duplicated or lost.",
        ["Tier 1: signed webhooks, de-duplicated by Stripe event id.", "Tier 2: instant server-side verification when the patient returns to the app.",
         "Tier 3: a background job re-checks any payment still pending after 2 minutes, so no booking is left stuck.",
         "A separate poll keeps each facility's charge and payout status current."], g)

    # ───────── PAY-4 Refund & dispute ─────────
    s = Seq("PAY4_Refund_Dispute", "PAY-4 · Refunds and Disputes — originate from the hospital's account")
    s.part("tr", "Hospital / platform admin", "refund request API", "user"); s.part("pay", "Payment service", "")
    s.part("st", "Stripe (UAE)", "hospital's account", "external"); s.part("ha", "Hospital", "Stripe Dashboard", "hospital")
    s.sec("1 · Refund")
    s.msg("tr", "pay", "refund request: transaction, amount, reason category, commission handling", num="①")
    s.msg("pay", "pay", "validate against transaction · create Refund = PENDING", "sync", "②")
    s.msg("pay", "st", "create refund on hospital account", "money", "③")
    s.msg("st", "pay", "charge.refunded (webhook)", "async", "④")
    s.msg("pay", "pay", "Refund = PROCESSED · Transaction REFUNDED / PARTIALLY_REFUNDED · commission reversed in proportion", "sync", "⑤")
    s.note("st", "Funds return to the patient's card from the hospital's Stripe balance, not from DoctorNow.", "pay")
    s.sec("2 · Dispute / chargeback")
    s.msg("st", "pay", "charge.dispute.created", "async", "⑦")
    s.msg("pay", "pay", "store Dispute (amount, fee, evidence due date) · Transaction = DISPUTED", "sync", "⑧")
    s.msg("ha", "st", "submit evidence in own Stripe Dashboard", "async", "⑨")
    s.msg("st", "pay", "charge.dispute.closed (won / lost)", "async", "⑩")
    s.msg("pay", "pay", "update Dispute outcome and Transaction status", "sync", "⑪")
    mod(pack, "PAY-4", "Refunds & Disputes", "How cancellation refunds and card disputes are processed.",
        ["Refunds are created on the hospital's connected account because the hospital is the Merchant of Record.",
         "Reason categories cover on-time and late cancellation, doctor cancellation or no-show, technical failure, quality complaint, chargeback and manual admin refunds.",
         "When a refund reverses part of a payment, the matching share of the platform commission is reversed so it is never invoiced.",
         "Disputes are recorded for visibility; the hospital responds inside its own Stripe Dashboard."], s)

    # ───────── PAY-5 Commission invoicing ─────────
    s = Seq("PAY5_Commission_Invoicing", "PAY-5 · Commission Invoicing — separate B2B billing outside Stripe")
    s.part("jb", "Invoice job", "scheduled", "neutral"); s.part("pay", "Payment service", "ledger")
    s.part("sa", "Super Admin svc", "billing terms"); s.part("ha", "Hospital admin", "portal", "user"); s.part("su", "Super admin", "console", "user")
    s.sec("1 · Invoice generation each billing cycle")
    s.msg("jb", "pay", "daily check: has the hospital's billing cycle ended?", num="①")
    s.msg("pay", "sa", "get billing cycle (weekly / bi-weekly / monthly)", num="②")
    s.msg("pay", "pay", "sum unbilled transactions minus commission already refunded", "sync", "③")
    s.msg("pay", "pay", "create invoice UNPAID, number + due date · mark transactions as billed", "sync", "④")
    s.sec("2 · Invoice paid by bank transfer (outside Stripe)")
    s.msg("ha", "pay", "view invoice and line items", num="⑤")
    s.msg("ha", "ha", "pays DoctorNow by bank transfer", "async", "⑥")
    s.msg("ha", "pay", "submit payment reference / receipt → PAYMENT_SUBMITTED", num="⑦")
    s.msg("su", "pay", "review → acknowledge (PAID) or reject with reason", num="⑧")
    s.note("pay", "Transactions already billed are never billed again; a cycle with no activity still advances the billing period.", "sa")
    mod(pack, "PAY-5", "Commission Invoicing", "How DoctorNow's technology fee is billed to hospitals separately from patient payments.",
        ["The fee is calculated per transaction and invoiced once per billing cycle; it is never deducted at checkout.",
         "Hospitals pay by bank transfer, submit the reference in the portal, and a DoctorNow admin acknowledges it.",
         "Each transaction carries an invoice reference so it can be billed only once."], s)

    # ───────── MOD-09 Notification ─────────
    g = Graph("MOD09_Notification", "MOD-09 · Notification Service", "LR", ranksep=1.0)
    g.node("src", "Producing services", "Appointment · Identity · Records\nPayment · Admin", "built")
    g.node("mq", "RabbitMQ", "channel queues: email · sms · push · in-app\nOTP queue + retry queue", "data")
    g.cluster("ns", "Notification service", "built")
    g.node("wk", "Workers", "OTP worker · channel consumers\nretry & dead-letter", "built", "ns")
    g.node("tp", "Templates", "OTP email · OTP SMS · prescription email", "built", "ns")
    g.node("api", "Notification APIs", "single · bulk · broadcast · banner\nread · delete · device registry", "built", "ns")
    g.node("pg", "PostgreSQL", "Notification · UserDevice", "data")
    g.cluster("ch", "Delivery channels", "external")
    g.node("em", "SMTP email", "nodemailer", "external", "ch")
    g.node("sm", "Twilio SMS", None, "external", "ch")
    g.node("fc", "Firebase FCM", "push", "external", "ch")
    g.node("ws", "Socket.io in-app", "realtime", "built", "ch")
    g.edge("src", "mq", "publish", "async"); g.edge("src", "api", "REST", "sync"); g.edge("mq", "wk", "consume", "async"); g.edge("wk", "tp"); g.edge("api", "pg"); g.edge("wk", "pg")
    for c in ["em", "sm", "fc", "ws"]: g.edge("wk", c, None, "async")
    mod(pack, "MOD-09", "Notification", "Multi-channel notifications: OTP, reminders, alerts, prescription email, banners.",
        ["Messages are queued per channel with retry queues so delivery survives provider outages.",
         "Device tokens are stored per user for push delivery."], g)

    # ───────── MOD-10 Hospital Admin ─────────
    g = Graph("MOD10_Hospital_Admin", "MOD-10 · Hospital Admin Service & Portal", "LR", ranksep=1.0)
    g.node("ha", "Hospital admin portal", None, "user"); g.node("gw", "API Gateway", "tenant-scoped", "security")
    g.cluster("hs", "Hospital admin service", "built")
    g.node("dr", "Doctor onboarding", "registers doctor account and profile\nthrough the Identity and Profile services", "built", "hs")
    g.node("sv", "Health services & packages", "services · packages · pricing", "built", "hs")
    g.node("ss", "Stripe status", "reads facility status", "built", "hs")
    g.node("pg", "PostgreSQL", "HealthService · HealthPackage\nPackageService", "data")
    g.node("s3", "Object storage", "images · documents", "data")
    g.node("pf", "Profile service", "doctor & admin records", "built")
    g.node("pay", "Payment service", "transactions · invoices · disputes · refunds", "built")
    g.edge("ha", "gw"); g.edge("gw", "dr"); g.edge("gw", "sv"); g.edge("gw", "ss"); g.edge("dr", "pg"); g.edge("sv", "pg"); g.edge("sv", "s3", None, "async")
    g.edge("dr", "pf", "internal", "ref"); g.edge("ss", "pay", "sync-status", "ref"); g.edge("gw", "pay", "finance views (hospital scoped)", "ref")
    mod(pack, "MOD-10", "Hospital Admin", "Facility self-service: doctors, services, packages, revenue and Stripe connection status.",
        ["Every request is scoped to the administrator's own hospital through tenant context.",
         "Revenue, transactions, refunds, disputes and commission invoices are served by the Payment service and shown in the portal."], g)

    # ───────── MOD-11 Super Admin ─────────
    g = Graph("MOD11_Super_Admin", "MOD-11 · Super Admin Service & Console", "LR", ranksep=1.0)
    g.node("su", "Super admin console", None, "user"); g.node("gw", "API Gateway", None, "security")
    g.cluster("ss", "Super admin service", "built")
    g.node("hs", "Hospital registry & approval", "DHA and trade licence documents\nsubmit → approve / reject / send back\nactivate · deactivate · override", "built", "ss")
    g.node("fn", "Finance terms", "commission rate · billing cycle per hospital", "built", "ss")
    g.node("bn", "Banners & announcements", None, "built", "ss")
    g.node("tk", "Support tickets", "create · reply · status · timeline", "built", "ss")
    g.node("in", "Internal APIs", "commission-rate · stripe-status\nhospital search", "built", "ss")
    g.node("pg", "PostgreSQL", "Hospital · Finance · Banners\nSupportTicket · TicketTimeline", "data")
    g.node("pay", "Payment service", "reads terms · writes Stripe status", "built")
    g.node("dha", "DHA facility licence verification", None, "hospital")
    g.edge("su", "gw"); g.edge("gw", "hs"); g.edge("gw", "fn"); g.edge("gw", "bn"); g.edge("gw", "tk")
    for a in ["hs", "fn", "bn", "tk"]: g.edge(a, "pg")
    g.edge("pay", "in", "internal API", "ref"); g.edge("in", "fn", None, "ref"); g.edge("hs", "dha", "licence documents reviewed", "ref")
    mod(pack, "MOD-11", "Super Admin", "Platform governance: hospital approval, commercial terms, announcements and support.",
        ["A hospital goes through a controlled approval workflow before it can be activated on the platform.",
         "Commission rate and billing cycle are held per hospital and consumed by the Payment service over internal APIs.",
         "Facility Stripe status is written back here so the console shows which hospitals can accept payments."], g)

    # ───────── MOD-12 Audit & Compliance ─────────
    g = Graph("MOD12_Audit_Compliance", "MOD-12 · Audit & Compliance", "TB", ranksep=1.0, nodesep=0.5)
    g.node("gw", "API Gateway", "request audit events", "security")
    g.node("svc", "Domain services", "publish business audit events\nvia the gateway", "built")
    g.cluster("b", "Implemented", "built")
    g.node("ev", "Audit events", "actor · role · action · target · IP\nbefore / after values · correlation id", "built", "b")
    g.node("rd", "Redaction", "passwords · tokens · card fields", "built", "b")
    g.node("mg", "MongoDB AuditLog", "queryable by hospital, entity, user, action", "data", "b")
    g.node("ap", "Audit log API", "SUPER_ADMIN: all · HOSPITAL_ADMIN: own hospital", "built", "b")
    g.cluster("p", "Planned compliance layer", "planned")
    g.node("im", "Immutable audit store", "write-once retention", "planned", "p")
    g.node("cr", "Compliance reports", "DHA / PDPL extracts", "planned", "p")
    g.node("si", "SIEM & incident process", "breach notification", "planned", "p")
    g.edge("gw", "ev"); g.edge("svc", "ev"); g.edge("ev", "rd"); g.edge("rd", "mg"); g.edge("mg", "ap")
    g.edge("mg", "im", "archive", "plan"); g.edge("im", "cr", None, "plan"); g.edge("mg", "si", None, "plan")
    mod(pack, "MOD-12", "Audit & Compliance", "How actions are recorded and how audit evidence is made available.",
        ["Implemented: structured audit events with before/after values and redaction, stored in MongoDB and exposed to authorised administrators.",
         "Planned: a dedicated compliance service with write-once retention, regulatory report extracts and an incident-response workflow."], g)
