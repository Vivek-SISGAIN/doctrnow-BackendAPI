import sys, importlib
sys.path.insert(0, '.')
import dn
OUT = '../out'
pack = dn.Pack(OUT)
for m in sys.argv[1:] or ['overall']:
    importlib.import_module(m).build(pack)
TARGET={'SYS-05','MOD-08','PAY-1','PAY-2','PAY-3','PAY-4','PAY-5'}
for i in pack.items:
    if i['ref'] in TARGET:
        i['target']=True; i['purpose']='Target design — implementation in progress. '+i['purpose']
order={'Overall':0,'Modules':1,'Payment flows':2}
pack.items.sort(key=lambda i:order[i['group']])
pack.build()
print(len(pack.items), 'diagrams built')

import pdfpack, os
pdfpack.make_pdf(pack, os.path.join(OUT, 'DoctorNow_Architecture_Dossier.pdf'))
print('pdf ok', os.path.getsize(os.path.join(OUT,'DoctorNow_Architecture_Dossier.pdf'))//1024, 'KB')
