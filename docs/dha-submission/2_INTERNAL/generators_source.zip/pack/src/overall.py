from dn import Graph, Seq

def build(pack):
    # ───────────────────────── A. Solution Context ─────────────────────────
    g = Graph("SYS01_Platform_Context", "SYS-01 · Platform Context", "TB", ranksep=1.0, nodesep=0.5, size=16)
    g.cluster("users", "Users & channels", "user")
    g.node("pat", "Patient", "Web app (responsive)", "user", "users")
    g.node("patm", "Patient & Doctor mobile apps", "iOS / Android (React Native)", "user", "users")
    g.node("doc", "Doctor", "Doctor portal (web)", "user", "users")
    g.node("hadm", "Hospital / Clinic Admin", "Hospital admin portal (web)", "user", "users")
    g.node("sadm", "DoctorNow Super Admin", "Platform admin console (web)", "user", "users")
    g.cluster("plat", "DoctorNow Platform — UAE-hosted (target: Microsoft Azure UAE North)", "cloud")
    g.node("gw", "API Gateway", "JWT/RBAC · rate limit · audit trail\nsingle HTTPS entry point", "security", "plat")
    g.node("core", "DoctorNow domain services (10)",
           "Identity · Profile · Appointment · Consultation · Video & Chat\nMedical Records & e-Rx · Payment · Notification\nHospital Admin · Super Admin", "built", "plat")
    g.cluster("pay", "Payments", "external")
    g.node("stripe", "Stripe Connect (UAE)", "Standard accounts · Direct Charges\nHospital = Merchant of Record\nPatient pays on Stripe-hosted Checkout", "external", "pay")
    g.cluster("vid", "Real-time video & communications", "external")
    g.node("agora", "Agora RTC", "encrypted media: patient ⇄ doctor\n(DoctorNow issues tokens only)", "external", "vid")
    g.node("fcm", "Firebase Cloud Messaging", "push notifications", "external", "vid")
    g.node("sms", "Twilio SMS / OTP", "OTP & alerts", "external", "vid")
    g.node("mail", "SMTP email provider", "transactional email", "external", "vid")
    g.cluster("eco", "UAE healthcare ecosystem", "hospital")
    g.node("ehr", "Hospital / Clinic EHR-HIS", "Cerner FHIR R4 sandbox connected\nEpic · TrakCare · Insta etc.", "hospital", "eco")
    g.node("nabidh", "NABIDH (Dubai HIE)", "submitted by the facility EMR", "hospital", "eco")
    g.node("rcm", "Hospital RCM / eClaimLink", "insurance & claims (facility-owned)", "hospital", "eco")
    g.node("dha", "Dubai Health (DHA)", "licensing & telehealth standards", "hospital", "eco")
    g.edge("agora", "fcm", kind="hid"); g.edge("sms", "mail", kind="hid"); g.edge("ehr", "dha", kind="hid"); g.edge("nabidh", "rcm", kind="hid"); g.edge("fcm", "sms", kind="hid", constraint=False)
    for u in ["pat", "doc", "hadm", "sadm"]: g.edge(u, "gw", "HTTPS / TLS")
    g.edge("patm", "gw", "HTTPS / TLS")
    g.edge("gw", "core", "authenticated requests")
    g.edge("core", "stripe", "Direct Charge · webhooks", both=True)
    g.edge("core", "agora", "RTC token", constraint=True)
    g.edge("core", "fcm", "push trigger"); g.edge("core", "sms", "OTP / SMS"); g.edge("core", "mail", "email")
    g.edge("core", "ehr", "FHIR R4 / HL7", both=True)
    g.edge("ehr", "nabidh", "facility HIE submission", "ref"); g.edge("ehr", "rcm", "eligibility · claims", "ref")
    g.edge("core", "dha", "compliance / audit evidence", "ref")
    pack.add("SYS-01", "Overall", "Platform Context",
        "Shows who uses DoctorNow and which external systems it exchanges data with. Items drawn dashed-yellow are planned and not yet implemented in the codebase.",
        ["Patients, doctors, hospital administrators and DoctorNow staff reach the platform only through the API Gateway over HTTPS.",
         "Patient consultation payments are charged directly on the hospital's Stripe Standard account (Direct Charge); DoctorNow never holds patient funds.",
         "Video uses Agora real-time media; DoctorNow issues short-lived tokens only. Push, SMS and email are sent through the Notification service.",
         "EHR integration is live against a Cerner FHIR R4 sandbox; NABIDH submission and insurance claims run through each facility's own systems and are outside the current release."], g)

    # ───────────────────────── B. Deployment ─────────────────────────
    g = Graph("SYS02_Runtime_Hosting", "SYS-02 · Runtime & Hosting Topology", "TB", ranksep=0.9, nodesep=0.45, size=19)
    g.cluster("cc", "Client channels", "user")
    g.node("c0", "Patient app · Doctor portal", "web applications", "user", "cc")
    g.node("c1", "Hospital admin portal · Super admin console", "web applications", "user", "cc")
    g.cluster("aws", "Microsoft Azure — UAE North (Dubai)", "cloud")
    g.cluster("edge", "Edge protection", "security", "aws")
    g.node("r53", "Azure DNS + managed certificates", "DNS · TLS certificates", "security", "edge", planned=True)
    g.node("waf", "Front Door / App Gateway WAF", "OWASP rules · DDoS Protection", "security", "edge", planned=True)
    g.node("alb", "Application Gateway (ingress)", "TLS termination · HTTPS only", "security", "edge", planned=True)
    g.cluster("k8s", "Private application subnets — Azure Kubernetes Service (AKS)", "built", "aws")
    g.node("gw", "API Gateway (NestJS)", "JWT · RBAC · throttling\ncircuit breaker · audit publisher", "built", "k8s")
    g.node("svc1", "Clinical & scheduling services", "Identity · Profile · Appointment\nConsultation · Medical Records\ncontainer images (Node.js)", "built", "k8s")
    g.node("svc2", "Business & communication services", "Payment · Notification · Video & Chat\nHospital Admin · Super Admin\ncontainer images (Node.js)", "built", "k8s")
    g.cluster("dat", "Private data subnets", "data", "aws")
    g.node("pg", "PostgreSQL (database per service)", "Prisma · target: Azure Database for PostgreSQL\nencryption at rest with Key Vault keys (planned)", "data", "dat")
    g.node("mongo", "MongoDB", "chat messages · audit log\ntarget: Azure Cosmos DB for MongoDB", "data", "dat")
    g.node("redis", "Redis", "slot locks · token blacklist · rate limits\nreminder job queue (BullMQ)\ntarget: Azure Cache for Redis", "data", "dat")
    g.node("mq", "RabbitMQ — Notification service only", "OTP and channel queues (email · SMS · push · in-app)\nin the AKS cluster", "data", "dat")
    g.node("s3", "Azure Blob Storage", "documents · prescriptions · reports\nprivate endpoint · Key Vault keys", "data", "dat", planned=True)
    g.cluster("mgd", "Managed security & operations services", "neutral", "aws")
    g.node("kms", "Azure Key Vault", "customer-managed keys · secrets", "neutral", "mgd", planned=True)
    g.node("cw", "Azure Monitor / Log Analytics", "PHI-free logs · alerts · activity log", "neutral", "mgd", planned=True)
    g.node("ecr", "Azure Container Registry", "signed images", "neutral", "mgd", planned=True)
    g.cluster("ext", "External services (egress via NAT Gateway / Azure Firewall, allow-listed)", "external")
    g.node("x1", "Stripe · Agora · Firebase · Twilio · SMTP", "see SYS-01", "external", "ext")
    g.node("x2", "Hospital EHR-HIS / NABIDH", "VPN / mTLS / private API", "hospital", "ext", planned=True)
    g.same("alb", "waf", "r53"); g.same("pg", "mongo", "redis", "mq", "s3"); g.same("kms", "cw", "ecr")
    g.edge("c0", "r53", "HTTPS"); g.edge("c1", "r53", "HTTPS")
    g.edge("r53", "waf", constraint=False); g.edge("waf", "alb", constraint=False); g.edge("alb", "gw", "HTTPS", "plan")
    g.edge("gw", "svc1", "REST"); g.edge("gw", "svc2", "REST")
    g.edge("svc1", "pg", "SQL / TLS"); g.edge("svc2", "pg", None)
    g.edge("svc2", "mongo", "TLS"); g.edge("svc1", "redis", "TLS"); g.edge("svc2", "mq", "AMQP"); g.edge("svc1", "s3", "private endpoint")
    g.edge("pg", "kms", "encrypt", "ref"); g.edge("s3", "kms", "encrypt", "ref")
    g.edge("svc2", "x1", "HTTPS egress"); g.edge("svc1", "x2", "private link", "plan")
    pack.add("SYS-02", "Overall", "Runtime & Hosting Topology",
        "Logical deployment of DoctorNow in the UAE cloud region: network segregation, containerised services, per-service data stores and managed security services.",
        ["All services are packaged as container images and run behind a single API Gateway; databases and object storage sit in private data subnets with no public access.",
         "Target hosting is Microsoft Azure UAE North (Dubai) on Azure Kubernetes Service. Edge services (WAF/Application Gateway), managed databases, Blob Storage, Key Vault and monitoring are planned platform work and are drawn dashed.",
         "Each service owns its own PostgreSQL database; chat and audit events use MongoDB. Redis provides slot locks, token revocation, rate limiting and the BullMQ queue for appointment reminders. RabbitMQ is used only by the Notification service; Kafka carries identity events in the Identity service; it is switched on by configuration and is on in the production profile.",
         "Planned: outbound calls to Stripe, Agora, Firebase, Twilio and email leave only through controlled, allow-listed egress."], g)

    # ───────────────────────── C. Interoperability ─────────────────────────
    g = Graph("SYS03_Interoperability_Boundary", "SYS-03 · Healthcare Interoperability Boundary", "TB", ranksep=1.0, nodesep=0.5)
    g.cluster("core", "DoctorNow core services", "built")
    g.node("prof", "Profile & Registry", "demographics · Emirates ID", "built", "core")
    g.node("appt", "Appointment & Scheduling", "slots · bookings", "built", "core")
    g.node("mr", "Medical Records & e-Rx", "notes · prescriptions · reports", "built", "core")
    g.cluster("gwl", "FHIR access layer (built)", "built")
    g.node("fgw", "API Gateway — /fhir endpoints", "authenticated FHIR access", "security", "gwl")
    g.node("fsvc", "FHIR service (payment-insurance module)", "Patient · Encounter · Observation\nCondition · MedicationRequest · Practitioner", "built", "gwl")
    g.cluster("fac", "Licensed facilities (system of record)", "hospital")
    g.node("cer", "Cerner / Oracle Health", "FHIR R4 sandbox — connected", "hospital", "fac")
    g.node("oth", "Epic · TrakCare · Insta", "per-facility HIS", "hospital", "fac")
    g.cluster("hie", "Dubai HIE", "hospital")
    g.node("nab", "NABIDH", "clinical information exchange", "hospital", "hie")
    g.cluster("ins", "Insurance (separate from NABIDH)", "hospital")
    g.node("rcm", "Hospital RCM → eClaimLink / payers", "provider-owned", "hospital", "ins")
    for s in ["prof", "appt", "mr"]: g.edge(s, "fgw", None)
    g.edge("fgw", "fsvc", "REST / JSON"); g.edge("fsvc", "cer", "FHIR R4 (OAuth)", both=True)
    g.edge("cer", "nab", "facility submission", "ref"); g.edge("oth", "nab", "facility submission", "ref")
    pack.add("SYS-03", "Overall", "Healthcare Interoperability Boundary",
        "How DoctorNow exchanges clinical data with hospital EHR/HIS systems and the Dubai Health Information Exchange using HL7 FHIR R4.",
        ["Implemented today: FHIR R4 read access exposed through the API Gateway and a FHIR service connected to a Cerner sandbox.",
         "Outside the current release: DoctorNow-built adapters for NABIDH, other EMR/HIS vendors and insurance claims. These are scoped per facility if required.",
         "Hospitals remain the clinical system of record and submit to NABIDH; DoctorNow does not submit to NABIDH directly.",
         "Insurance eligibility and claims stay on the hospital's revenue-cycle path, separate from clinical exchange."], g)

    # ───────────────────────── D. Teleconsultation flow (sequence) ─────────────────────────
    s = Seq("SYS04_Consultation_Session_Flow", "SYS-04 · Teleconsultation Session Flow")
    s.part("pat", "Patient app", "web", "user"); s.part("doc", "Doctor portal", "web", "user")
    s.part("gw", "API Gateway", "JWT · RBAC", "security"); s.part("ap", "Appointment", "slots · bookings")
    s.part("co", "Consultation", "lobby · consent · notes"); s.part("vc", "Video & Chat", "Socket.io · MongoDB")
    s.part("ag", "Agora RTC", "real-time media", "external"); s.part("mr", "Medical Records", "e-Rx · documents")
    s.part("nt", "Notification", "SMS · email · push")
    s.sec("1 · Booking confirmed (after payment — see Payment module)")
    s.msg("ap", "nt", "booking confirmed → reminder jobs scheduled (BullMQ / Redis)", "async", "①")
    s.msg("nt", "pat", "reminder notification (push / in-app / SMS / email)", "async", "②")
    s.sec("2 · Join, consent and media")
    s.msg("pat", "gw", "join request (JWT)", num="③"); s.msg("gw", "co", "join-lobby for appointment", num="④")
    s.msg("doc", "co", "join-lobby / request recording consent", num="⑤"); s.msg("co", "pat", "consent request → patient accepts", "async", "⑥")
    s.msg("pat", "gw", "request RTC token", num="⑦"); s.msg("gw", "pat", "short-lived Agora token + channel", "sync", "⑧")
    s.msg("pat", "ag", "encrypted audio/video", "async", "⑨"); s.msg("doc", "ag", "encrypted audio/video", "async", "⑨")
    s.msg("pat", "vc", "chat & attachments (Socket.io)", "async", "⑩"); s.msg("doc", "vc", "chat & attachments", "async", "⑩")
    s.sec("3 · Clinical documentation and completion")
    s.msg("doc", "co", "consultation notes & vitals", num="⑪"); s.msg("doc", "mr", "issue & sign e-prescription", num="⑫")
    s.msg("mr", "nt", "prescription available → email / notification", "async", "⑬")
    s.msg("doc", "co", "end consultation", num="⑭"); s.msg("co", "ap", "mark appointment complete", num="⑮")
    pack.add("SYS-04", "Overall", "Teleconsultation Session Flow",
        "End-to-end sequence for a teleconsultation: reminders, lobby and consent, real-time media and chat, clinical notes, e-prescription and completion.",
        ["Media is carried by Agora; DoctorNow only mints short-lived tokens through the API Gateway and never relays media itself.",
         "Recording consent is requested from the patient in the consultation lobby and the request and acceptance times are stored; audio and video are not recorded by DoctorNow.",
         "Prescriptions are stored as documents in object storage and delivered by email/notification; notification payloads carry no clinical content.",
         "Consultation notes, vitals and prescriptions are owned by the Consultation and Medical Records services respectively."], s)

    # ───────────────────────── E. Payment architecture ─────────────────────────
    g = Graph("SYS05_Payment_Direct_Charges", "SYS-05 · Payment Architecture — Direct Charges", "TB", ranksep=1.15, nodesep=0.5)
    g.cluster("pa", "Patient", "user")
    g.node("p", "Patient app", "selects slot & pays", "user", "pa")
    g.cluster("dn", "DoctorNow platform", "cloud")
    g.node("pay", "Payment service", "Checkout · webhooks · reconciliation\nrefunds · ledger", "built", "dn")
    g.node("ledg", "Commission ledger & invoices", "per-transaction commission\nB2B invoice per billing cycle", "data", "dn")
    g.node("apt", "Appointment service", "slot hold → CONFIRMED", "built", "dn")
    g.cluster("st", "Stripe (UAE)", "external")
    g.node("co", "Stripe Checkout (hosted)", "③ patient pays here:\ncard · wallets · 3-D Secure", "external", "st")
    g.node("wh", "Webhooks", "platform + Connect events (signed)", "external", "st")
    g.cluster("hm", "Hospital — Merchant of Record", "hospital")
    g.node("acct", "Standard connected account", "100% of consultation fee\nStripe fees borne by hospital", "hospital", "hm")
    g.node("bank", "Hospital corporate bank account", "automatic payouts", "hospital", "hm")
    g.node("dash", "Hospital Stripe Dashboard", "disputes · payouts · negative balances", "hospital", "hm")
    g.edge("p", "pay", "checkout", num="①")
    g.edge("pay", "co", "create Session", num="②")
    g.edge("co", "acct", "100% of fee", "money", "④")
    g.edge("acct", "bank", "payout", "money", "⑤")
    g.edge("wh", "pay", "webhook", "async", "⑥")
    g.edge("pay", "apt", "PAID", "sync", "⑦")
    g.edge("pay", "ledg", "commission owed", "sync", "⑧")
    g.edge("ledg", "acct", "B2B invoice", "ref", "⑨")
    g.edge("pay", "acct", "refund", "money", "⑩")
    g.edge("acct", "dash", "manages", "ref")
    pack.add("SYS-05", "Overall", "Payment Architecture — Direct Charges",
        "Funds and data flow for patient consultation payments. The hospital is the Merchant of Record; DoctorNow never holds or splits patient funds.",
        ["Hospitals onboard as Stripe Standard connected accounts. Checkout Sessions are created on the hospital's own account (Direct Charge) with no application fee.",
         "Card data is entered on Stripe-hosted Checkout and never reaches DoctorNow; only Stripe object IDs and card brand/last4 are stored.",
         "Refunds, disputes, chargebacks and payouts are the hospital's responsibility inside its own Stripe account.",
         "DoctorNow's technology fee is recorded on an internal ledger and billed to the hospital by separate B2B invoice, paid by bank transfer outside Stripe.",
         "Payment state is protected by three tiers: signed webhooks, instant verification when the patient returns, and a background reconciliation job."], g)

    # ───────────────────────── F. Data classification & residency ─────────────────────────
    g = Graph("SYS06_Data_Classification_Residency", "SYS-06 · Data Classification & Residency", "LR", ranksep=1.1)
    g.cluster("dc", "Data classes", "neutral")
    g.node("phi", "PHI", "consult notes · vitals · prescriptions\nreports · chat content", "security", "dc")
    g.node("pii", "PII", "name · Emirates ID · DOB · phone · email", "user", "dc")
    g.node("pay", "Payment data", "card / wallet credentials", "external", "dc")
    g.node("ops", "Operational & audit", "logs · metrics · audit trail", "neutral", "dc")
    g.cluster("uae", "UAE boundary — DoctorNow hosted (target: Azure UAE North)", "cloud")
    g.node("pg", "PostgreSQL (per service)", "profiles · appointments · consultations\nprescriptions · payment references", "data", "uae")
    g.node("s3", "Object storage", "Azure Blob Storage (target)\ndocuments · prescriptions · reports", "data", "uae")
    g.node("mg", "MongoDB", "chat · audit events (PII/body redacted)", "data", "uae")
    g.node("lg", "Application logs", "PHI excluded by policy", "neutral", "uae")
    g.cluster("ho", "Licensed facilities / DHA", "hospital")
    g.node("ehr", "Facility EHR-HIS", "clinical system of record", "hospital", "ho")
    g.cluster("xp", "External processors — residency assessment per provider", "planned")
    g.node("stripe", "Stripe", "card data tokenised, PCI-DSS", "external", "xp")
    g.node("agora", "Agora", "media in transit", "external", "xp")
    g.node("fcm", "Firebase FCM", "device tokens · notification text", "external", "xp")
    g.node("sms", "SMS / email providers", "phone · email · OTP", "external", "xp")
    g.edge("phi", "pg"); g.edge("phi", "s3"); g.edge("phi", "mg"); g.edge("phi", "ehr", "FHIR exchange", "ref")
    g.edge("phi", "agora", "in transit only", "async")
    g.edge("pii", "pg"); g.edge("pii", "fcm", "token only", "async"); g.edge("pii", "sms", "OTP / notices", "async")
    g.edge("pay", "stripe", "tokenised by Stripe Checkout", "money"); g.edge("ops", "lg"); g.edge("ops", "mg")
    pack.add("SYS-06", "Overall", "Data Classification & Residency",
        "Where each class of data is stored or processed, and which external processors touch it.",
        ["PHI and PII are stored only in DoctorNow's UAE-hosted databases and object storage, or in the licensed facility's own systems.",
         "Card and wallet data never enters DoctorNow systems; Stripe Checkout tokenises it.",
         "Application logs exclude PHI by policy; audit request bodies redact passwords, tokens and card fields.",
         "A residency and cross-border assessment is required for each external processor (Agora, Firebase, SMS/email, Stripe)."], g)

    # ───────────────────────── G. Security & access control ─────────────────────────
    g = Graph("SYS07_Security_Controls", "SYS-07 · Security Controls", "TB", ranksep=0.7, nodesep=0.35)
    g.cluster("ur", "User roles", "user")
    for i, r in enumerate(["PATIENT", "DOCTOR", "HOSPITAL_ADMIN", "SUPER_ADMIN"]): g.node(f"r{i}", r, None, "user", "ur")
    g.cluster("l1", "Layer 1 — Identity", "built")
    g.node("ids", "Identity Service", "password login + OTP second factor (patient, doctor)\nsessions · account lockout · revocation", "built", "l1")
    g.node("jwt", "RS256 access token (15 min)", "JWKS-verified · refresh token", "built", "l1")
    g.node("mfa", "MFA for admin roles", "hospital admin · super admin", "planned", "l1")
    g.cluster("l2", "Layer 2 — Perimeter", "security")
    g.node("waf", "WAF + DDoS Protection, App Gateway (TLS 1.3)", "OWASP rules · DDoS", "security", "l2", planned=True)
    g.node("gw", "API Gateway", "JWT guard · rate limiting · helmet\ncircuit breaker · token blacklist (Redis)", "security", "l2")
    g.cluster("l3", "Layer 3 — Application", "built")
    g.node("rbac", "Role + tenant enforcement", "role checks · x-tenant-id scoping\nhospital sees only its own data", "built", "l3")
    g.node("isec", "Service-to-service trust", "internal signature header on internal APIs", "built", "l3")
    g.cluster("l4", "Layer 4 — Data", "data")
    g.node("enc", "Encryption", "TLS in transit · AES-256 at rest (Key Vault keys)", "data", "l4", planned=True)
    g.node("net", "Private data subnets", "no public database access", "data", "l4", planned=True)
    g.cluster("mon", "Monitoring & governance", "neutral")
    g.node("aud", "Audit trail (gateway)", "who · what · when · before/after values\nsensitive fields redacted", "built", "mon")
    g.node("imm", "Immutable audit store & SIEM", "write-once retention · incident process", "neutral", "mon", planned=True)
    for r in ["r0", "r1", "r2", "r3"]: g.edge(r, "ids")
    g.edge("ids", "jwt"); g.edge("ids", "mfa", None, "plan"); g.edge("jwt", "waf"); g.edge("waf", "gw", None, "plan")
    g.edge("jwt", "gw"); g.edge("gw", "rbac"); g.edge("rbac", "isec"); g.edge("isec", "net", None, "plan"); g.edge("net", "enc", None, "plan")
    g.edge("gw", "aud", "access events", "async"); g.edge("aud", "imm", None, "plan")
    pack.add("SYS-07", "Overall", "Security Controls",
        "Layered controls from identity through perimeter, application, data and monitoring.",
        ["Identity: password login with an OTP second factor for patients and doctors, account lockout, RS256-signed 15-minute access tokens verified through JWKS, refresh tokens and server-side session revocation.",
         "Gateway: JWT guard, role-based access, rate limiting, secure headers, circuit breaker and a Redis token blacklist.",
         "Tenant isolation: hospital administrators are scoped to their own hospital via tenant context on every request.",
         "Every business action is written to an audit trail with actor, role, before/after values and redacted sensitive fields.",
         "Planned hardening: second factor for hospital admin and super admin accounts, WAF/Application Gateway, Key Vault-managed encryption, private data subnets, immutable audit storage and SIEM."], g)

    # ───────────────────────── H. Service dependency map ─────────────────────────
    g = Graph("SYS08_Service_Dependency_Map", "SYS-08 · Service Dependency Map", "TB", ranksep=1.0, nodesep=0.5)
    for k, (n, s_) in {"id": ("Identity", "auth-service"), "pf": ("Profile", "profile-service"), "ap": ("Appointment", "appointment-service"),
                       "co": ("Consultation", "consultation-service"), "vc": ("Video & Chat", "video-chat-service"), "mr": ("Medical Records", "medical-records-service"),
                       "py": ("Payment", "payment-insurance-service"), "nt": ("Notification", "notification-service"),
                       "ha": ("Hospital Admin", "hospital-admin-service"), "sa": ("Super Admin", "super-admin-service")}.items():
        g.node(k, n, s_, "built")
    g.node("mq", "RabbitMQ", "notification queues", "data"); g.node("st", "Stripe", None, "external")
    g.node("gw", "API Gateway", "client entry point · carries most\nservice-to-service calls", "security")
    g.edge("id", "nt", "OTP delivery"); g.edge("nt", "mq", "queue", "async")
    g.edge("ap", "pf", "doctor data"); g.edge("ap", "co", "consultation records"); g.edge("ap", "nt", "reminders")
    g.edge("co", "ap", "complete appointment"); g.edge("co", "vc", "chat sessions")
    g.edge("pf", "co", "doctor's patients"); g.edge("pf", "ap", "appointments"); g.edge("pf", "sa", "hospital data")
    g.edge("py", "ap", "payment outcome"); g.edge("py", "pf", "patient / hospital lookup"); g.edge("py", "sa", "commission terms · Stripe status")
    g.edge("py", "st", "Direct Charges · webhooks", "money")
    g.edge("ha", "pf", "doctor profiles"); g.edge("ha", "id", "doctor accounts"); g.edge("ha", "py", "sync-status"); g.edge("ha", "sa", "hospital data")
    g.edge("mr", "nt", "prescription email"); g.edge("nt", "pf", "recipient lookup")
    g.edge("gw", "ap", "all client traffic", "ref")
    pack.add("SYS-08", "Overall", "Service Dependency Map",
        "Logical dependencies between services, derived from the calls each service makes.",
        ["All client traffic enters through the API Gateway; most service-to-service calls are also routed through it, a few services call each other directly, and internal endpoints are protected by a shared secret header.",
         "The Payment service talks directly to the Appointment, Profile and Super Admin services and is the only component that talks to Stripe.",
         "Appointment reminders are scheduled as BullMQ jobs on Redis; OTP, email, SMS, push and in-app messages are queued in RabbitMQ by the Notification service.",
         "Video & Chat and Medical Records are reached through the gateway and by the Consultation and Notification services respectively."], g)
