import os, textwrap
from reportlab.lib.pagesizes import A3, landscape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader, simpleSplit
from PIL import Image
pdfmetrics.registerFont(TTFont("DV", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DVB", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
W, H = landscape(A3); M = 36
NAVY, GREY, LINE = (0.07, 0.22, 0.31), (0.33, 0.39, 0.44), (0.81, 0.85, 0.87)
LEG = [("#FFF1E0", "#B45309", "User / client channel"), ("#E7F0FA", "#1D4E89", "Implemented — in the DoctorNow codebase"),
       ("#EAF6E7", "#3F7D20", "Data store"), ("#EEEAF8", "#4C3D91", "External provider"), ("#E0F4F2", "#0F766E", "Hospital / regulator system"),
       ("#FDEBEB", "#B3261E", "Security / edge control"), ("#EEF0F3", "#475569", "Platform / operations"), ("#FFF9DB", "#C28A00", "Planned — designed, not yet implemented (dashed)")]

def hexrgb(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) / 255 for i in (0, 2, 4))

def footer(c, n, total, label):
    c.setStrokeColorRGB(*LINE); c.line(M, 30, W - M, 30)
    c.setFont("DV", 8); c.setFillColorRGB(*GREY)
    c.drawString(M, 18, f"DoctrNow Healthcare LLC-FZ · {label} · Dossier v1.0 · 6 November 2026 · Confidential")
    c.drawRightString(W - M, 18, f"Page {n} of {total}")

def para(c, text, x, y, width, font="DV", size=10.5, lead=14, color=(0.15, 0.2, 0.25), bullet=False):
    c.setFont(font, size); c.setFillColorRGB(*color)
    lines = simpleSplit(text, font, size, width - (12 if bullet else 0))
    for i, ln in enumerate(lines):
        if bullet and i == 0: c.drawString(x, y, "•")
        c.drawString(x + (12 if bullet else 0), y, ln); y -= lead
    return y

def make_pdf(pack, path, label="DoctorNow Platform Architecture Dossier"):
    items = pack.items; total = 2 + len(items); c = canvas.Canvas(path, pagesize=(W, H))
    c.setTitle("DoctorNow — Platform Architecture Dossier"); c.setAuthor("DoctrNow Healthcare LLC-FZ")
    # cover
    c.setFillColorRGB(1, 1, 1); c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColorRGB(*NAVY); c.rect(0, 0, 150, H, fill=1, stroke=0)
    c.setFillColorRGB(0.06, 0.46, 0.43); c.rect(150, 0, 10, H, fill=1, stroke=0)
    c.setFillColorRGB(*NAVY); c.setFont("DVB", 15); c.drawString(210, H - 120, "DoctrNow Healthcare LLC-FZ")
    c.setFont("DVB", 46); c.drawString(210, H - 230, "DoctorNow")
    c.setFont("DVB", 28); c.drawString(210, H - 280, "Platform Architecture Dossier")
    c.setFont("DV", 14); c.setFillColorRGB(*GREY)
    c.drawString(210, H - 316, "System views, module views and payment flows — prepared for Dubai Health (DHA) IT verification")
    y = H - 400
    ng = lambda g: sum(1 for i in items if i["group"] == g)
    for k, v in [("Document reference", "DN-ARCH-DOSSIER-2026"), ("Version", "1.0 — 6 November 2026"),
                 ("Status", "Issued for DHA IT review — planned items are marked as such"), ("Companion documents", "Architecture Specification v1.1 (DN-ARCH-SPEC-2026) · Compliance Matrix (DN-COMP-MATRIX-2026)"),
                 ("Contents", f"{len(items)} views — {ng('Overall')} system (SYS), {ng('Modules')} module (MOD), {ng('Payment flows')} payment flow (PAY)"),
                 ("Hosting basis", "Microsoft Azure UAE North (Dubai) — target environment")]:
        c.setFont("DV", 10); c.setFillColorRGB(0.06, 0.46, 0.43); c.drawString(210, y, k.upper()); c.setFont("DVB", 13); c.setFillColorRGB(*NAVY); c.drawString(420, y, v); y -= 32
    c.setFont("DV", 9.5); c.setFillColorRGB(*GREY); c.drawString(210, 60, "Confidential — prepared by DoctrNow Healthcare LLC-FZ for the Dubai Health Authority. Not for onward distribution.")
    c.showPage()
    # overview + index
    c.setFillColorRGB(*NAVY); c.setFont("DVB", 22); c.drawString(M, H - 60, "Document overview and index")
    y = para(c, "This pack describes the DoctorNow teleconsultation platform at two levels: the overall system (views SYS-01 to SYS-08), each individual module (MOD-00 to MOD-12) "
                "and the payment module's flows (PAY-1 to PAY-5). The dossier accompanies the Architecture Specification v1.1 (DN-ARCH-SPEC-2026) and the Compliance Matrix (DN-COMP-MATRIX-2026).", M, H - 90, W - 2 * M, size=11, lead=15)
    y -= 6
    howto = ("Solid boxes are implemented in the current DoctorNow codebase. Dashed yellow boxes marked \"Planned\" are part of the current release plan but not yet built or deployed. "
             "Payment views (SYS-05, MOD-08, PAY-1 to PAY-5) show the target design; implementation is in progress. Status terms match the Architecture Specification (Section 1.1) and the Compliance Matrix.")
    hl = simpleSplit(howto, "DV", 10.5, W - 2 * M - 24); bh = 30 + len(hl) * 14
    c.setFillColorRGB(0.96, 0.97, 0.98); c.setStrokeColorRGB(0.11, 0.31, 0.54); c.setLineWidth(1.2); c.roundRect(M, y - bh + 8, W - 2 * M, bh, 4, fill=1, stroke=1)
    c.setFont("DVB", 10.5); c.setFillColorRGB(*NAVY); c.drawString(M + 12, y - 8, "How to read these diagrams")
    yy = y - 24
    for ln in hl: c.setFont("DV", 10.5); c.setFillColorRGB(0.15, 0.2, 0.25); c.drawString(M + 12, yy, ln); yy -= 14
    y = y - bh - 4
    y -= 8; c.setFont("DVB", 12); c.setFillColorRGB(*NAVY); c.drawString(M, y, "Legend"); y -= 20
    for i, (f, l, t) in enumerate(LEG):
        x = M + (i % 2) * 560; yy = y - (i // 2) * 24
        c.setFillColorRGB(*hexrgb(f)); c.setStrokeColorRGB(*hexrgb(l)); c.setLineWidth(1.6)
        if "Planned" in t: c.setDash(3, 2)
        c.roundRect(x, yy - 4, 22, 14, 3, fill=1, stroke=1); c.setDash()
        c.setFont("DV", 10); c.setFillColorRGB(0.15, 0.2, 0.25); c.drawString(x + 32, yy, t)
    y -= 4 * 24 + 18
    c.setFont("DVB", 12); c.setFillColorRGB(*NAVY); c.drawString(M, y, "Index"); y -= 18
    col = [M, M + 55, M + 380]; row = 13.2; n = 3
    for g in ["Overall", "Modules", "Payment flows"]:
        c.setFont("DVB", 9.5); c.setFillColorRGB(*GREY); c.drawString(col[0], y, {"Overall": "SYSTEM VIEWS", "Modules": "MODULE VIEWS", "Payment flows": "PAYMENT FLOWS"}[g]); y -= row
        for it in [i for i in items if i["group"] == g]:
            it["page"] = 3 + items.index(it)
            c.setFont("DVB", 9.5); c.setFillColorRGB(*NAVY); c.drawString(col[0], y, it["ref"])
            c.setFont("DV", 9.5); c.setFillColorRGB(0.15, 0.2, 0.25); c.drawString(col[1], y, it["title"])
            c.setFillColorRGB(*GREY); c.drawString(col[2], y, simpleSplit(it["purpose"], "DV", 9.5, W - col[2] - 90)[0] + ("…" if len(simpleSplit(it["purpose"], "DV", 9.5, W - col[2] - 90)) > 1 else ""))
            c.drawRightString(W - M, y, f"p. {it['page']}"); y -= row
    footer(c, 2, total, label); c.showPage()
    # diagram pages
    tmp = os.path.join(pack.outdir, "_pdf"); os.makedirs(tmp, exist_ok=True)
    for idx, it in enumerate(items):
        pageno = 3 + idx
        c.setFillColorRGB(*NAVY); c.setFont("DVB", 20); c.drawString(M, H - 52, f"{it['ref']} · {it['title']}")
        c.setFont("DV", 8.5); c.setFillColorRGB(*GREY); c.drawRightString(W - M, H - 58, {"Overall": "SYSTEM VIEWS", "Modules": "MODULE VIEWS", "Payment flows": "PAYMENT FLOWS"}[it["group"]])
        if it.get("target"):
            c.setFillColorRGB(1.0, 0.95, 0.84); c.setStrokeColorRGB(0.76, 0.54, 0.0); c.setLineWidth(1)
            c.roundRect(W - M - 250, H - 40, 250, 16, 3, fill=1, stroke=1); c.setFillColorRGB(0.54, 0.35, 0.0); c.setFont("DVB", 8.5)
            c.drawCentredString(W - M - 125, H - 35, "TARGET DESIGN — IMPLEMENTATION IN PROGRESS")
        y = para(c, it["purpose"], M, H - 74, W - 2 * M, size=11, lead=15)
        im = Image.open(it["base"] + ".png"); aspect = im.width / im.height
        scale = min(1.0, 3400 / im.width)
        if scale < 1: im = im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS)
        p = os.path.join(tmp, f"{idx}.png"); im.save(p, optimize=True)
        top = y - 6
        if aspect < 1.3:      # tall: image left, notes right
            nx = W - M - 330; box = (M, 44, nx - M - 14, top - 44)
            ny = top - 4
        else:
            note_h = 18 + sum(len(simpleSplit(n_, "DV", 9.5, W - 2 * M - 12)) for n_ in it["notes"]) * 12.5 + len(it["notes"]) * 3
            box = (M, 44 + note_h, W - 2 * M, top - 44 - note_h); nx = M; ny = 44 + note_h - 6
        bx, by, bw, bh = box; s = min(bw / im.width, bh / im.height); dw, dh = im.width * s, im.height * s
        c.drawImage(ImageReader(p), bx + (bw - dw) / 2, by + (bh - dh) / 2 + (0 if aspect < 1.3 else 0), dw, dh, mask="auto")
        c.setFont("DVB", 10); c.setFillColorRGB(*NAVY); c.drawString(nx, ny, "Key points"); yy = ny - 16
        for n_ in it["notes"]:
            yy = para(c, n_, nx, yy, (330 if aspect < 1.3 else W - 2 * M), size=9.5, lead=12.5, bullet=True) - 3
        footer(c, pageno, total, label); c.showPage()
    c.save()
